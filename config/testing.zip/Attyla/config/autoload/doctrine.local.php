<?php
 
$dbParams = array(
    'hostname' => '51.254.35.102',
    'port' => 5432,
    'username' => 'attyla-admin',
    'password' => 'attyla2015',
    'database' => 'attyla'
);
 
return array(
    'doctrine' => array(
        'connection' => array(
            'orm_default' => array(
                'driverClass' => 'Doctrine\DBAL\Driver\PDOPgSql\Driver',
                'params' => array(
                    'host' => $dbParams['hostname'],
                    'port' => $dbParams['port'],
                    'user' => $dbParams['username'],
                    'password' => $dbParams['password'],
                    'dbname' => $dbParams['database'],
//                    'driverOptions' => array(
//                        \PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'
//                    ),
                )
            )
        )
    )
);