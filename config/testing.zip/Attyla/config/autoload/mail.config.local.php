<?php
return array(
	'mail' => array(
		'transport' => array(
			'options' => array(
				'host'              => 'localhost',
				'connection_class'  => 'plain',
				'connection_config' => array(
					'username' => '',
					'password' => ''
//					'ssl' => ''
				),
			),  
		),
	),
);