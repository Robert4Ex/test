<?php
return array(
    // //Place it into main config folder ////
    'settings' => array(
        'BASE_URL' => 'attyla.xyz',//http://example.com
        "EMAIL" => array(
            "SMTP_SENDER_TYPE" => "user",
            "SMTP_NAME" => "localhost",
            "SMTP_HOST" => "localhost",
            "SMTP_PORT" => "25",
            "SMTP_CONNECTION_CLASS" => "plain",
            "SMTP_USERNAME" => "",
            "SMTP_PASSWORD" => "",
            "SMTP_SSL" => "",
            "BODY" => "Hello there!",
            "FROM" => "attyla@arturlasocha.pl",
            "TO" => "TO_URL",
            "MAIL_FROM_NICK_NAME" => "Attyla - administracja",
            "SUBJECT" => "SUBJECT_OF_THE_MAIL",
            "FROM_NICK_NAME" => "NICK_NAME",
            'UPDATE_EMAIL_TEMPLATE' => true
        ),
        'FORGOT_PASSWORD_SUBJECT' => 'Reset Password Mail',
        'REGISTRATION_MAIL_SUBJECT' => 'Please, confirm your registration!'
    ),
    'afterLoginURL' => 'application', //Change it where your application redirects after login
    'controllers' => array(
        'invokables' => array(
            'Users\Controller\User' => 'Users\Controller\UserController'
        )
    ),
    'whitelist' => array(
        '/auth',
        '/auth/index/login',
        '/auth/registration/index',
        '/auth/index/logout',
        '/auth/index/forgotten-password',
        '/auth/registration/forgotten-password',
        '/auth/registration/registration-success',
        '/auth/registration/confirm-email',
        '/auth/registration/password-change-success',
    )
    
);
