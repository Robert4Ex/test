<?php 

/**
 * Zawiera podstawowe metody służące do pobierania danych z bazy
 *  
 * @author alasocha
 * @version
 */
namespace Logic\Db;

use Zend\Db\Adapter\Adapter;

class Table extends TableGateway
{
    /**
     * Singleton instances
     */
    protected static $_instances = array();

    /**
     * Wskazanie na klasę zestawu wierszy
     * @var string
     */
    protected $_rowsetClass = 'Logic_Db_Table_Rowset';
    protected $_rowClass = 'Logic_Db_Table_Row';


    protected $dictionaryNameFields = array('id');

    protected static $_rowCache = array();
    

    /**
     * ustawiamy czy cache ma byc obslugiwany czy nie
     *
     * @var unknown_type
     */
    protected $allowCache = false;
    protected $cacheLifeTime = 60;
    
    public function setSchema($schema){
    	$this->_schema = $schema;
    }
    
    public function select($withFromPart = self::SELECT_WITHOUT_FROM_PART)
    {
        require_once 'Zend/Db/Table/Select.php';
        require_once 'Logic/Db/Table/Select.php';
        $select = new Logic_Db_Table_Select($this);
        if ($withFromPart == self::SELECT_WITH_FROM_PART) {
            $select->from($this->info(self::NAME), Zend_Db_Table_Select::SQL_WILDCARD, $this->info(self::SCHEMA));
        }
        return $select;
    }


    /**
     * zwraca nazwe sekwencji
     * jesli nie jest podana, to ja ustawia i zwraca
     * @return string
     */
    public function getSeq(){
        return $this->info('sequence');
    }

    /**
     * wl/wyl cachowanie zapytan tabeli
     *
     * @param unknown_type $allow
     */
    public function allowCache( $allow = true )
    {
        $this->allowCache = (boolean) $allow;
    }

    /**
     * ustawiamy czas waznosci cachu w sekundach
     * @param int $time
     */
    public function setCacheLifeTime ( $time=60 )
    {
        $this->cacheLifeTime = (int) $time;
    }

    /**
     * zwraca na ile sekund ustawiona jest waznosc cachu
     * @return int
     */
    public function getCacheLifeTime()
    {
        return $this->cacheLifeTime;
    }

    /**
     *
     * wlacza cache, ustawiajac je waznosc na podana wartosc sekund
     * jesli nie podamy wartosci time, domyslnie dane cachowane sa na 30 dni
     * @param int $time
     */
    public function cacheOn($time = 0)
    {
        $this->allowCache(true);
        if ($time == 0) {
            $time = 24 * 60 * 60;
        }
        $this->setCacheLifeTime($time);
        return $this;
    }

    /**
     * wylaczna cachowanie
     */
    public function cacheOff()
    {
        $this->allowCache(false);
        return $this;
    }

    /**
     * zwraca obiekt cache
     * @return mixed
     */
    public function getCache()
    {
        $cacheManager = Zend_Registry::get('cache_manager');
        return $cacheManager->getCache('default');
    }

    /**
     * Czyści cache z powiązanych wpisów
     *
     */
    public function cleanCache()
    {
        /* @var $cache Logic_Cache_Memcached */
        if (($cache = $this->getCache())) {
            $cache->clean(Zend_Cache::CLEANING_MODE_MATCHING_ANY_TAG, array($this->_name));
        }
    }

    /**
     * Fetches a new blank row (not from the database).
     *
     * @param  array $data OPTIONAL data to populate in the new row.
     * @param  string $defaultSource OPTIONAL flag to force default values into new row
     * @return Zend_Db_Table_Row_Abstract
     */
    public function createRow(array $data = array(), $defaultSource = null)
    {
        $row = parent::createRow($data, $defaultSource);
        $row->setNew();
        return $row;
    }

    /* (non-PHPdoc)
     * @see Zend_Db_Table_Abstract::fetchAll()
     */
    public function fetchAll($where = null, $order = null, $count = null, $offset = null)
    {
        if (!($cache = $this->getCache()) || !$this->allowCache) {
            return parent::fetchAll($where, $order, $count, $offset);
        }

        $cache->setLifetime($this->getCacheLifeTime());

        if ($where instanceof Zend_Db_Select) {
            $cacheKey = $this->_name.'_'.md5((string)$where);
        } else {
            $cacheKey = $this->_name.'_'.md5('where'.$where.'order'.$order.'count'.$count.'offset'.$offset);
        }

        if ($cache->test($cacheKey)) {
            return $cache->load($cacheKey);
        }

        $result = parent::fetchAll($where, $order, $count, $offset);
        $cache->save($result, $cacheKey, array($this->_name));

        return $result;
    }

    /* (non-PHPdoc)
     * @see Zend_Db_Table_Abstract::fetchRow()
     */
    public function fetchRow($where = null, $order = null, $offset = null)
    {
        if (!($cache = $this->getCache()) || !$this->allowCache) {
            return parent::fetchRow($where, $order, $offset);
        }

        if ($where instanceof Zend_Db_Select) {
            $cacheKey = $this->_name.'_'.md5((string)$where).'_row';
        } else {
            $cacheKey = $this->_name.'_'.md5('where'.$where.'order'.$order.'offset'.$offset).'_row';
        }

        if ($cache->test($cacheKey)) {
            return $cache->load($cacheKey);
        }

        $result = parent::fetchRow($where, $order, $offset);
        $cache->save($result, $cacheKey, array($this->_name));

        return $result;
    }

    /**
     * zwraca primary keya
     * @return string
     */
    public function getPrimaryKey()
    {
        return implode(',',$this->info('primary'));
    }

    public function getName()
    {
        return $this->_name;
    }
    
    public function canUseCache()
    {
        return true;
    }

    /**
     * Returns an instance of Logic_Db_Table
     *
     * Singleton patterns implementation
     * (non-PHPdoc)
     */
    public static function getInstance()
    {
        $class = get_called_class();
        if (!isset(static::$_instances[$class])) {
            static::$_instances[$class] = new static;
        }
        return static::$_instances[$class];
    }

    /**
     * dodaje wiele wierszy do tabeli.
     * @param array $data - tablic z danymi
     * @param array $keys - tablica z kolumnami
     * @return array - tablica z idkami dodanych wierszy
     */
    public function insertRows($data, $keys){
        $return = array();
        if (empty($data) || empty($keys)){
            return array();
        }

        $query = 'INSERT INTO ' . (($this->_schema ? $this->_schema . '.' : '') . $this->_name) . ' ';

        $query .= '('.implode(',',$keys).') ';

        $query .= 'VALUES ';

        $queryVals = array();
        foreach ($data as $row) {
            foreach($row as &$col) {
                if ($col !== null) {
                    if (is_bool($col)) {
                        if ($col === true) {
                            $col = 'TRUE';
                        }
                        else {
                            $col = 'FALSE';
                        }
                    }
                    else {
                        $col = $this->_db->quote($col);
                    }
                } else {
                    $col = 'NULL';
                }
            }
            $queryVals[] = '(' . implode(',', $row) . ')';
        }

        $query = $query . implode(',', $queryVals);
        $query .= ' RETURNING '.$this->getPrimaryKey();
        
        $ids = $this->_db->query($query)->fetchAll();
        
        $this->cleanCache();
        
        return $ids;
    }

    /**
     * dodaje wiele wierszy do tabeli. klucze tablicy wejsciowej beda polami tabeli
     * @param array $data
     * @return array
     */
    public function insertMany($data){
        if (!empty($data)){
            return $this->insertRows($data, array_keys($data[0]));
        }
        return array();
    }

    /* (non-PHPdoc)
     * @see Zend_Db_Table::find()
     */
    public function find()
    {
        $tableId = get_class($this);
        if (!isset(self::$_rowCache[$tableId])) {
            self::$_rowCache[$tableId] = array();
        }

        $args = func_get_args();
        $cacheId = serialize($args);

        if (isset(self::$_rowCache[$tableId][$cacheId])) {
            return self::$_rowCache[$tableId][$cacheId];
        }

        $result = forward_static_call_array(array('Zend_Db_Table', 'find'), $args);
        return (self::$_rowCache[$tableId][$cacheId] = $result);
    }

    public function findOne()
    {
        return call_user_func_array(array($this, 'find'), func_get_args())->current();
    }

    public static function rollback()
    {
        self::$_rowCache = array();
    }

    public function clearRowCache()
    {
        $tableId = get_class($this);
        if (!isset(self::$_rowCache[$tableId])) {
            return;
        }
        unset(self::$_rowCache[$tableId]);
    }

    public function delete($where)
    {
        $this->clearRowCache();
        $this->cleanCache();
        return parent::delete($where);
    }

    public function insert(array $data)
    {
        $this->cleanCache();
        return parent::insert($data);
    }

    public function update(array $data, $where)
    {
        $this->clearRowCache();
        $this->cleanCache();
        return parent::update($data, $where);
    }

	/**
	 * Zwraca tablice oznaczaną wg klucza - $key
	 * @param Zend_Db_Table_Rowset_Abstract|array $rowset
	 * @param string $key
	 * @return array
	 */
	protected function _toAssocArray($rowset, $key = 'id')
	{
		$toRet = array();
		if (count($rowset) > 0) {
			if ($rowset instanceOf Zend_Db_Table_Rowset_Abstract) {
				$rows = $rowset->toArray();
			} else {
				$rows = $rowset;
			}
			foreach ($rows as $row) {
				if (array_key_exists($key, $row)) {
					$toRet[$row[$key]] = $row;
				} else {
					throw new Exception('Could not convert to array. Key does not exist -' . $key);
				}
			}
		}
		return $toRet;
	}
	
	/**
	 * Wykonuje zapytanie
	 * Zwraca tablicę indeksowaną po id (patrz defaultowy parametr w _toAssocArray)
	 * @param string $query
	 * @return array 
	 */
	public function fetchAssoc($query, $key = 'id')
	{
	    return $this->_toAssocArray($this->getAdapter()->fetchAll($query), $key);    
	}
	
	
	/**
	 * Walidacja parametru daty
	 * @param string $param
	 * @throws Exception - jak sie nie powiedzie walidacja
	 * @return string
	 */
	public static function verifyDate($param, $nullable = false, $format = 'Y-m-d')
	{
	    if ($param instanceOf DateTime) {
	        return $param;
	    }
	    if (null == $param && $nullable) {
	        return $param;
	    }
	    try {
	        $el = new DateTime($param);
	        return $el->format($format);
	    } catch (Exception $e) {
	        throw new Logic_Db_TableException('verifyDate:Non date parameter - ' . $param);
	    }
	}
	
	/**
	 * Weryfikuje czy faktycnzie tablica zawiera same liczby
	 * @param array $arr
	 * @return array
	 */
	public static function verifyNumericArray($arr, $nullable = false)
	{
	    if ($arr instanceOf SplFixedArray) {
	        return $arr;
	    }
	    if ((null == $arr || is_array($arr) && count($arr) == 0) && $nullable) {
	        return $arr;
	    }
		if (is_array($arr)) {
			foreach ($arr as $id) {
				if (!is_numeric($id) && !((strlen($id) == 0 || $id == null) && $nullable)) {
					throw new Logic_Db_TableException('verifyNumericArray:Non numeric id - ' . $id);
				}
			}
			return $arr;	
		} else {
			self::verifyNumeric($arr);
			return array($arr);
		}
	}
	
	/**
	 * Sprawdzenie czy zadana wartośc jest numeryczna
	 * @param integer $val - wartość do sprawdzenia
	 * @throws Logic_Db_TableException - wyjątek dla sytuacji, gdy dana wartość nie jest numerykiem 
	 * @return $integer
	 */
    public static function verifyNumeric($val, $nullable = false)
	{
	    if (null == $val && $nullable) {
	        return $val;
	    }
		if (!is_numeric($val)) {
			throw new Logic_Db_TableException('verifyNumeric:Bad parameter - ' . $val . '.');
		}
		return $val;
	}
	
	/**
	 * Weryfikacja typu wartości
	 * @param boolean $val
	 * @throws Logic_Db_TableException
	 * @return boolean
	 */
	public static function verifyBoolean($val, $nullable = false)
	{
	    if (null == $val) {
	        return $val;
	    }
	    if (!in_array(strtolower($val), array('true', 'false', false, true, 0, 1))) {
	        throw new Logic_Db_TableException('verifyNumeric:Bad parameter - ' . $val . '.');
	    }
	    return $val;
	}
	
	/**
	 * Zwraca bazowe zapytanie select dla danego modelu
	 * @param $mainList - lista elementów do pobrania
	 * @return Ambigous <Zend_Db_Select, Zend_Db_Table_Select>
	 */
	public function getBaseQuery($mainList = array(), $alternativeAlias = false)
	{
	    $alternativeAlias = (is_array($alternativeAlias) && isset($alternativeAlias[0])) 
	        ? $alternativeAlias[0] 
	        : $alternativeAlias
	    ;
		return clone $this->select()
			->from(array(($alternativeAlias ? $alternativeAlias : $this->_name[0]) => $this->_name), $mainList)
			->setIntegrityCheck(false);
	}

	/**
	 * Zwraca separator
	 * @return string
	 */
	public static function getSeparator()
	{
		$config = Zend_Registry::get('config');
		if (isset($config['db']['separator'])) {
			$sep = $config['db']['separator'];
		} else {
			$sep = '|!|';
		}
		return $sep;
	}
    
    /**
     * Zwraca tablicę wyników (nazwa, id) na podstawie wyniku zapytania z  metody sql - array
     * @param string $string
     * @return array
     */
    public static function explodeArrayString($string){
        $strReplace = str_replace(array('{','}','"'), '', $string);
        $strExplode = explode(',', $strReplace);
        $arrayDes = array();
        
        foreach($strExplode as $str){
            $row = explode(self::getSeparator(), $str);
            @$arrayDes[] = array(
                'name' => $row[0],
                'id' => $row[1]
            );
        }
        return $arrayDes;
    }
    
	/**
	 * Weryfikacja emaila
	 * @param string $email
	 * @param boolean $nullable
	 * @throws Logic_Db_TableException
	 * @return string
	 */
	public static function verifyEmail($email, $nullable = false)
	{

	    if (null == $email && $nullable) {
	        return $email;
	    }
	    $validator = new Zend_Validate_EmailAddress(array('mx' => false, 'hostname' => null, 'domain'   => false));
	    if ($validator->isValid($email)) {
	        return $email;
	    } else {
	        throw new Logic_Db_TableException('Bad email format ' . $email);      
	    }
	}

	public function getDictionaryNameFields()
	{
	    return $this->dictionaryNameFields;
    }
    
    public function getHeaderMappings()
    {
        $row = new $this->_rowClass;
        return $row->getHeaderMappings();
    }

    public function getDictMappings()
    {
        $row = new $this->_rowClass;
        return $row->getDictMappings();
    }
    
    /**
     * 
     * @param array $change - @see getChangedFields
     * @param DateTime $changedAt
     * @return multitype
     */
    public function getFieldChanges($change)
    {
        
        $elementId = $change['id_element'];
        $changeArr = array();
        $fields = array();
        
        if ('' == $change['changed_columns']) {
            return array();
        }
        $changedColumns = explode(',', $change['changed_columns']);
        $changedColumns = array_diff($changedColumns, array('"id"'));
        
        foreach ($changedColumns as $field) {

        	if($field == '"id_case"'){
        		$tField = 'case when '.$field.'::text is not null then '.$field.'::text else \'NaN\' end as '.$field.'';
        	}else{
            	$tField = $field  . '::text';
        	}
        	$ftField = $field  . '::text';
            $fields[] = new Zend_Db_Expr($tField);
            $changeArr[trim($field, '"')] = new Zend_Db_Expr('first_not_nan(' . $ftField . ')');
        }
        
        foreach (array_keys($changeArr) as $field) {
            //element zostal zmieniony lub wiersz reprezentuje aktualna wartosc w systemie <=> change_list = NULL
            $fieldDefinitions[] = new Zend_Db_Expr("
                CASE 
        			WHEN '{$field}' = ANY(change_list) OR change_list IS NULL 
        			THEN {$field}::text
        			ELSE 'NaN'
        		END::text as {$field}    
            ");
        }
        
        $fields[] = 'id';
        $changeArr['id'] = 'first_not_nan(id::text)';
        $changesQuery = $this->getAdapter()
            ->select()
            ->from(array('audit._log_' . $change['obj_type']), array_merge($fields, array('shift_time', 'changed_columns')))
            ->where('shift_time > ?', $change['shift_time']) 
            //wieksze (NIE wieksze rowne), bo szukamy wartosci po zmianie w danym czasie
            ->where('id = ?', $elementId)
            ->where('alter_type != ?', 'VIEW')
        ;
        
        $currValQuery = $this->getAdapter()
            ->select()
            ->from(array('ct' => $change['obj_type']), array_merge($fields, array(
                'shift_time' => new Zend_Db_Expr('CURRENT_TIMESTAMP'),
                'changed_columns' => new Zend_Db_Expr('NULL')
            )))
            ->where('id = ?', $elementId)
        ;
        
        $query = $this->getAdapter()
            ->select()
            ->union(array(
                new Zend_Db_Expr('(' . $changesQuery . ')'),
                new Zend_Db_Expr('(' . $currValQuery . ')')
            ))
        ;
        $query = $this->getAdapter()
            ->select()
            ->from(array('x' => new Zend_Db_Expr('(' . $query . ')')), array(
                'change_list' => new Zend_Db_Expr("string_to_array(replace(changed_columns, '\"', ''), ',')"),
                '*'
            ))
            ->order('shift_time ASC')
        ;
        $query = $this->getAdapter()->select()
            ->from(array('raw_changes' => new Zend_Db_Expr('(' . $query . ')')), array_merge(
                $fieldDefinitions, array(new Zend_Db_Expr('id'))))
        ;
        $query = $this->getAdapter()
            ->select()
            ->from(array('not_nan' => new Zend_Db_Expr('(' . $query . ')')), $changeArr)
        ;

        return $this->fetchAssoc($query);
    } 
    
    /**
     * Opakowuje zapytania przekazaner w tablicy w bardziej przyjazna zendowi forme
     * @param array $arr
     * @return Zend_Db_Expr[]
     */
    public static function _wrapAsSubquery($arr)
    {
        $ret = array();
        foreach ($arr as $ar) {
            $ret[] = new Zend_Db_Expr('(' . $ar . ')');
        }
        return $ret;
    }
    
    
    /**
     * Pobiera instancje front commona
     * @param boolean $fetchMode
     * @return Zend_Db_Adapter_Abstract
     * @throws Exception Exception if no entry in config
     */
    public static function getFrontCommonAdapter($fetchMode = false) {
        $config = Zend_Registry::get('config');
        if (!(
            array_key_exists('resources', $config)
            && array_key_exists('multidb', $config['resources'])
            && array_key_exists('frontend_common', $config['resources']['multidb'])
        )) {
            throw new Exception('No entry in config for frontend_common');
        }
        //nie ustawiono parametru sesji wyłączającego replikację
        $adapter = Zend_Controller_Front::getInstance()
            ->getParam('bootstrap')
            ->getResource('multidb')
            ->getDb('frontend_common')
        ;
        if (false !== $fetchMode) {
            $adapter->setFetchMode($fetchMode);
        }
        return $adapter;
    }
    
    
    /**
     *
     * @return Zend_Db_Adapter_Abstract
     */
    public static function getAsyncAdapter($mode = false)
    {
        return self::_getReplicationAdapter('async', $mode);
    }
    
    /**
     * @return Zend_Db_Adapter_Abstract
     */
    public static function getSyncAdapter($mode = false)
    {
        return self::_getReplicationAdapter('sync', $mode);
    }
    
    /**
     * 
     * @param string $mode
     * @return Zend_Db_Adapter_Abstract
     */
    private static function _getReplicationAdapter($mode, $fetchMode = false)
    {
        $config = Zend_Registry::get('config');
        $sess = new Zend_Session_Namespace('config');
        if (
            (!isset($sess->{$mode . 'replication'}->off) 
            || false == $sess->{$mode . 'replication'}->off)
        ) {
            if (!(
                array_key_exists('resources', $config)
                && array_key_exists('multidb', $config['resources'])
                && array_key_exists('repsync', $config['resources']['multidb'])
                && array_key_exists('repasync', $config['resources']['multidb'])
            )) {
                return Zend_Db_Table::getDefaultAdapter();
            }
            //nie ustawiono parametru sesji wyłączającego replikację
            $adapter = Zend_Controller_Front::getInstance()
                ->getParam('bootstrap')
                ->getResource('multidb')
                ->getDb('rep' . $mode)
            ;
            if (false !== $fetchMode) {
                $adapter->setFetchMode($fetchMode);
            }
            return $adapter;
        } else {
            return Zend_Db_Table::getDefaultAdapter();
        }
    }
    
    /**
     * Usuwa z Rowa $return klucze, ktorych nie ma w $RowFindKeys
     * @param type $RowFindKeys Zend_Db_Table_Row_Abstract
     * @param type $return Zend_Db_Table_Row_Abstract
     * @return Zend_Db_Table_Row_Abstract
     */
    public function filterKeysFromRows($RowFindKeys, $return) {
        foreach($return as $key => $val) {
            if(!isset($RowFindKeys->$key)) {
                unset($return->$key);
            }
        }
        return $return;
    }
    
    /**
     * Rozbijamy PostgreSQLowa tablice
     * @param string $arrayString
     * @return type
     */
    public static function explodeArray($arrayString) {
        return explode(',', trim($arrayString, '{}'));
    }

    protected function _setupMetadata()
    {
        if ($this->metadataCacheInClass() && (count($this->_metadata) > 0)) {
            return true;
        }
    
        // Assume that metadata will be loaded from cache
        $isMetadataFromCache = true;
    
        // If $this has no metadata cache but the class has a default metadata cache
        if (null === $this->_metadataCache && null !== self::$_defaultMetadataCache) {
            // Make $this use the default metadata cache of the class
            $this->_setMetadataCache(self::$_defaultMetadataCache);
        }
    
        // If $this has a metadata cache
        if (null !== $this->_metadataCache) {
            // Define the cache identifier where the metadata are saved
    
            //get db configuration
            $dbConfig = $this->_db->getConfig();
    
            $port = isset($dbConfig['options']['port'])
            ? ':'.$dbConfig['options']['port']
            : (isset($dbConfig['port'])
                    ? ':'.$dbConfig['port']
                    : null);
    
            $host = isset($dbConfig['options']['host'])
            ? ':'.$dbConfig['options']['host']
            : (isset($dbConfig['host'])
                    ? ':'.$dbConfig['host']
                    : null);
    
            // Define the cache identifier where the metadata are saved
            $cacheId = md5( // port:host/dbname:schema.table (based on availabilty)
                    $port . $host . '/'. $dbConfig['dbname'] . ':'
                    . $this->_schema. '.' . $this->_name
            );
        }
    
        // If $this has no metadata cache or metadata cache misses
        if (null === $this->_metadataCache || !($metadata = $this->_metadataCache->load($cacheId))) {
            // Metadata are not loaded from cache
            $isMetadataFromCache = false;
            // Fetch metadata from the adapter's describeTable() method
            $metadata = $this->_db->describeTable($this->_name, $this->_schema);
            // If $this has a metadata cache, then cache the metadata
            if (null !== $this->_metadataCache) {
                $this->_metadataCache->save($metadata, $cacheId);
            }
        }
    
        // Assign the metadata to $this
        $this->_metadata = $metadata;
    
        // Return whether the metadata were loaded from cache
        return $isMetadataFromCache;
    }
    
    
    /**
     * Robi inserta na podstawie selecta do tabeli 
     * @param Zend_Db_Table_Select|string $select
     * @param array $cols Tablica z kolumnami do inserta
     * @param array $returning Tablica z returnowanymi kolumnami
     * @return array Tablica tablic,
     */
    public function insertFromSelect($select, $cols = array('*'), $returning = array('id')) {
        $insert = 'INSERT INTO ' . $this->getName() . '';
        if (!empty($cols) && count($cols)) {
            $insert .= '(' . implode(',', $cols) . ')';
        }
        
        $insert .= ' ((';
        if (is_string($select)) {
            $insert .= $select;
        }
        elseif ($select instanceof Zend_Db_Table_Select) {
            $insert .= $select->__toString();
        }        

        $insert .= ')) RETURNING ' . implode(',', $returning) . ';';
        $ret = $this->getAdapter()->fetchAll($insert);

        $this->cleanCache();

        return $ret;
    }

    public function getReferenceByRule($ruleKey)
    {
        if (!isset($this->_referenceMap[$ruleKey])) {
            return false;
        }
        return $this->_referenceMap[$ruleKey];
    }

    
    /**
     * Zwraca this select
     * @param array $columns Lista kolumn
     * @return Logic_Db_Table_Select
     */
    public static function query($columns = array())
    {
        $select = static::getInstance()->select();
        if (!empty($columns)) {
            $select->get($columns);
        } elseif ($columns === null) {
            $select->get(null);
        }
        return $select;
    }

    /**
     * Filtruje wg id
     * @param Logic_Db_Table_Select $select
     * @param Logic_Db_Table_Row|Logic_Db_Table_Rowset|integer|array $id
     */
    public function filterId(Logic_Db_Table_Select $select, $id)
    {
        if ($id instanceof Logic_Db_Table_Row || $id instanceof Logic_Db_Table_Rowset) {
            $id = $id->id;
        }
        $select->where($select->getAlias() . '.id IN (?)', $id);
    }

    /**
     * Odfiltrowuje wg id
     * @param Logic_Db_Table_Select $select
     * @param Logic_Db_Table_Row|Logic_Db_Table_Rowset|integer|array $id
     */
    public function excludeId(Logic_Db_Table_Select $select, $id)
    {
        if ($id instanceof Logic_Db_Table_Row || $id instanceof Logic_Db_Table_Rowset) {
            $id = $id->id;
        }
        $select->where($select->getAlias() . '.id NOT IN (?)', $id);
    }

    public function orderById(Logic_Db_Table_Select $select, $dir = 'ASC')
    {
        $dir = strtoupper($dir);
        $select->order($select->getAlias(null, false) . '.id ' . $dir);
    }
}