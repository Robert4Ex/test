<?php

/**
 * Debug
 * Klasa do obsługi debugu
 * 
 * @method Debug getInstance() returns an instance of Debug
 */
namespace Logic;

use Zend\Mvc\Controller;
use Zend\Authentication;

//require_once 'SqlFormater/Sql.php';
class Debug
{
    const DUMP_STACK = '_dumpStack_';

    const DUMP_EXIT = '_dumpExit_';

    const DUMP_PRINT = '_dumpPrint_';

    const DUMP_PLAIN = '_dumpPlain_';

    /**
     * Lista ip adresów developerów
     * @var array
     */
    protected $_developers = array(
        'alasocha',
        'rkawalec'
    );

    /**
     * Lista opcji
     * @var array
     */
    protected $_options = array();
    
    static protected $_instance;

    public function __construct($config = array())
    {
        $this->_options = $config;

        if (isset($this->_options['strict']) && $this->_options['strict']) {
            set_error_handler(array($this, 'handleError'), E_ALL);
        }
    }

    /**
     * Czy narzędzie debugowania włączone
     * @param string $tool
     * @return boolean
     */
    public function isEnabled($tool)
    {
        return isset($this->_options[$tool]) && (bool)$this->_options[$tool];
    }
    
    public function setNoticeLog($value = true)
    {
        if (!isset($this->_options['notice'])) {
            $this->_options['notice'] = array();
        }
        $this->_options['notice']['log'] = $value;
    }

    public function isNoticeLog()
    {
        return isset($this->_options['notice'])
            && isset($this->_options['notice']['log'])
            && $this->_options['notice']['log']
        ;
    }

    public function setNoticeDisplay($value = true)
    {
        if (!isset($this->_options['notice'])) {
            $this->_options['notice'] = array();
        }
        $this->_options['notice']['display'] = $value;
    }

    public function isNoticeDisplay()
    {
        return isset($this->_options['notice'])
            && isset($this->_options['notice']['display'])
            && $this->_options['notice']['display']
        ;
    }

    /**
     * Czy połączenie z maszyny developera
     * @return boolean
     */
    public function isDeveloper()
    {
        $auth = new Authentication\AuthenticationService();
        if ( ! $username = $auth->getIdentity()) {
            return true;
        }
        return in_array($username->username, $this->_developers, true);
    }

    public function dump()
    {
//        if (!isset($this->_options['die']) || !$this->_options['die']) {
//            return false;
//        }

        if( ! $this->isDeveloper() ){
            return false;
        }
        
        $method = 'var_dump';
        $variables = array();
        $options = array();

        foreach (func_get_args() as $var) {
            if (is_object($var) || is_array($var)) {
                $variables[] = $var;
                continue;
            }
            switch ((string)$var) {
                case self::DUMP_PRINT:
                case self::DUMP_PLAIN:
                    $method = 'print_r';
                case self::DUMP_STACK:
                case self::DUMP_EXIT:
                    $options[$var] = true;
                    break;
                default:
                    $variables[] = $var;
            }
        }

        $controller = new Controller\AbstractConsoleController();
        $request = $controller->getRequest();
        if (!$request || $request->isXmlHttpRequest()) {
            $options[self::DUMP_PLAIN] = true;
        }

        ob_start();

        if (isset($options[self::DUMP_STACK])) {
            echo '<pre>' . new \Exception() . '</pre>' . "\n";
        }

        foreach ($variables as $var) {

            if ($var instanceof \Zend\Db\Sql\Select) {

                echo "<h2>I'm select, dude!</h2>\n";
                echo \SqlFormater\Sql::format((string)$var->getSqlString()) . "\n";

            } elseif (is_object($var)) {

                echo "<h2>I'm object, dude!</h2>" . "\n";
                echo '<h3>Class: ' . get_class($var) . '</h3>' . "\n";
                echo '<pre>';

                if (method_exists(get_class($var), 'toArray')) {
                    $method($var->toArray()) . '<br />';
                } else {
                    $method($var) . "<br />\n";
                }

                echo "<br />\n";
                echo '</pre>';
                
            } elseif (is_resource($var)) {
                
                echo "<h2>I'm resource, dude!</h2>" . "\n";
                echo '<pre>';
                $method($var) . "<br />\n";
                echo "<br />\n";
                echo '</pre>';

            } elseif (is_array($var) && is_object(current($var))) {

                echo "<h2>I'm array of objects, dude!</h2>" . "\n";
                echo '<h3>' . count($var) . ' elements of ' .get_class(current($var)) . ' class</h3>' ."\n";
                echo '<pre>';

                if (count($var) > 100) {
                    $arr = array();
                    foreach ($var as $key => $val) {
                        if (method_exists(get_class($val), 'toArray')) {
                            $arr[$key] = $val->toArray();
                        } else {
                            $arr[$key] = $val;
                        }
                    }
                    $method($arr);
                } else {
                    foreach ($var as $key => $val) {
                        if (is_object($val)) {
                            echo sprintf('<b>[%s] object(%s) => </b>', $key, get_class($val));
                        } else {
                            echo sprintf('<b>[%s] => </b>', $key);
                        }
                        if (is_object($val) && method_exists(get_class($val), 'toArray')) {
                            $method($val->toArray());
                        } else {
                            $method($val);
                        }
                        echo "<br />\n";
                    }
                }

                echo '</pre>';

            } elseif (!is_array($var) && preg_match('/(select |insert into |update |delete )/i', $var)) {

                echo "<h2>I'm sql statement, dude!</h2>\n";
                echo \SqlFormater\Sql::format((string)$var) . "\n";

            } else {

                echo '<pre>';

                if ($method != 'var_dump' && is_string($var) && !isset($options[self::DUMP_PLAIN])) {
                    $var = htmlentities($var);
                }
                $method($var)  . "<br />\n";

                echo '</pre>';
            }
        }

        $ret = ob_get_clean();

        if (isset($options[self::DUMP_PLAIN])) {
            header('Content-Type: text/plain');
            $ret = strip_tags($ret);
        }

        echo $ret;

        if (isset($options[self::DUMP_EXIT])) {
            exit;
        }
    }

    public function handleError($errno, $errstr, $errfile = null, $errline = null, $errcontext = array())
    {
        $path = str_replace(realpath(getcwd() . '/..'), '', $errfile);
        $message = sprintf('%s in %s@%d', $errstr, $path, (int)$errline);

        switch ($errno) {
            case E_ERROR:
        	case E_USER_ERROR:
        	case E_RECOVERABLE_ERROR:
        	    $message = '[ERROR] ' . $message;
        	    break;
        	case E_WARNING:
        	    $message = '[WARNING] ' . $message;
        	    break;
        	case E_NOTICE:
        	    $message = '[NOTICE] ' . $message;
        	    break;
    	    case E_USER_NOTICE:
        	    error_log('[NOTICE] ' . $message);
        	    return;
    	    case E_USER_WARNING:
    	        error_log('[WARNING] ' . $message);
    	        return;
        	default:
        	    return;
        }

        throw new Exception($message);
    }

    static public function getInstance($config = array())
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new Debug($config);
        }
        return self::$_instance;
    }
}