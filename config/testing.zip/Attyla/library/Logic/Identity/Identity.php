<?php

/* 
 * Author : Artur Łasocha
 * Klasa rozszerzająca AuthentocationService
 *  */

namespace Logic\Identity;

class Identity extends \Zend\Authentication\AuthenticationService
{
    /**
     * id zalogowane usera
     */
    protected $_id = null;
    
    /**
     * Return Id logged user
     *
     * @return int
     */
    public function setId($storage)
    {
        return $this->_id;
    } 
    
    /**
     * Return Id logged user
     *
     * @return int
     */
    public function getId()
    {
        return $this->_id;
    }
    
}

