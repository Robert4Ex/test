<?php

/**
 * PRZYKŁAD WYWOŁANIA W WIDOKU:
 *
 * $this->boxDialog('#id','branch','tree', array(
 *		'params'=>array(
 *			'title'=>'Wybierz jednostkę w strukturze<br />Open Finance S. A.',
 *			'url'=>'/branch/tree',
 *		),
 *		'events'=>array(
 *			'afterLoadContent'=>new Zend_Json_Expr('defaultOptions.treeBoxDialogOptions.afterLoadContent'),	
 *		),
 * ));
 *
 */
namespace Logic\View\Helper;

use Zend\View\Exception;
use Zend\View\Helper\AbstractHelper;

class boxDialog extends AbstractHelper
{
	public function boxDialog($id,$controller,$action, $options = array())
	{
		$permission = new Logic_View_Helper_Permission();
		$param = array(array('controller'=>$controller, 'action'=>$action));
		
		if((is_null($controller) && is_null($action)) || $permission->permission($param)){
			//sprawdzanie czy popup ma wymaganą szerokość
			if(isset($options['params']['width'])){
			    $options['params']['width'] = (int)$options['params']['width'];
				if($options['params']['width'] == 300){
					$options['params']['width'] = 400;
				}
				else if($options['params']['width'] == 400){
					
				}
				else if($options['params']['width'] == 500){
					
				}
				else if($options['params']['width'] == 1000){
					
				}
				else{
					throw new Exception('The specified width is not allowed');
				}
			}
			//ustawienie domyślnej szerokości
			else{
				$options['params']['width'] = 500;
			}
			$options['params'] = array_merge(array('resizable'=>false), $options['params']);
			
			$this->renderAllowedScript($id,$options);
		}
		else{
			$this->renderForbiddenScript($id);
		}
	}
	
	public function renderAllowedScript($id,$options)
	{
		$html = '<script type="text/javascript">$(function(){'."\n";
		$html .= 'var config = '.Zend_Json::encode($options, false, array('enableJsonExprFinder' => true)).';'."\n";
		$html .= '$("'.$id.'").boxDialog(config)'."\n";
		$html .= '});</script>';

		echo $html;
	}
	
	public function renderForbiddenScript($id)
	{
		$html = '<script type="text/javascript">$(function(){'."\n";
		$html .= 'var config = '.Zend_Json::encode(array('params'=>array('disabledExtension'=>true)), false, array('enableJsonExprFinder' => true)).';'."\n";
		$html .= '$("'.$id.'").boxDialog(config)'."\n";
		$html .= '});</script>';
		
		echo $html;
	}
}