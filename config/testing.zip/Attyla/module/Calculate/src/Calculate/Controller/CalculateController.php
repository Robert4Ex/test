<?php
/*
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 * 
 * Data powstania: 24-01-2016
 * 
 */

namespace Calculate\Controller;

use Zend\Mvc\Controller\AbstractActionController;

class CalculateController extends AbstractActionController
{
    public function indexAction()
    {
        return array();
    }

  
}
