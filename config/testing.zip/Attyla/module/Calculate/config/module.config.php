<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Calculate\Controller\Calculate' => 'Calculate\Controller\CalculateController',
        ),
    ),
    'router' => array(
        'routes' => array(
            'module-name-here' => array(
                'type'    => 'Literal',
                'options' => array(
                    'route'    => '/calculate',
                    'defaults' => array(
                        'controller'    => 'Calculate\Controller\Calculate',
                        'action'        => 'index',
                    ),
                ),
                'may_terminate' => true,
                'child_routes' => array(
                    'default' => array(
                        'type'    => 'Segment',
                        'options' => array(
                            'route'    => '/[:controller[/:action]]',
                            'constraints' => array(
                                'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'action'     => '[a-zA-Z][a-zA-Z0-9_-]*',
                            ),
                            'defaults' => array(
                            ),
                        ),
                    ),
                ),
            ),
        ),
    ),
    'view_manager' => array(
        'template_path_stack' => array(
            'Calculate' => __DIR__ . '/../view',
        ),
    ),
);
