<?php

return array(
    'controllers' => array(
        'invokables' => array(
            'Calculator\Controller\Range' => 'Calculator\Controller\RangeController',
            'Calculator\Controller\Calculate' => 'Calculator\Controller\CalculateController',
            'Calculator\Controller\Customer' => 'Calculator\Controller\CustomerController',
            'Calculator\Controller\PriceSettings' => 'Calculator\Controller\PriceSettingsController',
        ),
    ),
    'router' => array(
        'routes' => array(
            'range' => array(
                'type' => 'segment',
                'options' => array(
                    'route' => '/range[/:action[/:id]]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                    'defaults' => array(
                        'controller' => 'Calculator\Controller\Range',
                        'action' => 'index',
                    ),
                ),
            ),
            'calculate-poster' => array(
                'type' => 'segment',
                'options' => array(
                    'route' => '/calculate-poster[/:action[/:id]]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                    'defaults' => array(
                        'controller' => 'Calculator\Controller\Calculate',
                        'action' => 'index',
                    ),
                ),
            ),
            'select-calculate' => array(
                'type' => 'segment',
                'options' => array(
                    'route' => '/select-calculate[/:action]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                    'defaults' => array(
                        'controller' => 'Calculator\Controller\Calculate',
                        'action' => 'selectCalculate',
                    ),
                ),
            ),
            'customer' => array(
                'type' => 'segment',
                'options' => array(
                    'route' => '/customer[/:action[/:id]]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                    'defaults' => array(
                        'controller' => 'Calculator\Controller\Customer',
                        'action' => 'index',
                    ),
                ),
            ),
            'pricesettings' => array(
                'type' => 'segment',
                'options' => array(
                    'route' => '/pricesettings[/:action[/:id]]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                    'defaults' => array(
                        'controller' => 'Calculator\Controller\PriceSettings',
                        'action' => 'index',
                    ),
                ),
            ),
        ),
    ),
    'view_manager' => array(
        'template_path_stack' => array(
            'calculator' => __DIR__ . '/../view',
        ),
    ),
);
