<?php

/*
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 * 
 * Data zmian: 18-10-2015
 * 
 */

namespace Calculator\Form;

use Zend\Form\Form;
use Zend\Db\Adapter\AdapterInterface;

class CuttingForm extends Form {

    protected $Adapter;

    protected function setDbAdapter(AdapterInterface $dbAdapter) {

        $this->Adapter = $dbAdapter;
        return $this;
    }

    protected function getDbAdapter() {

        return $this->dbAdapter;
    }

    public function __construct(AdapterInterface $dbAdapter, $name = null) {

        $this->Adapter = $dbAdapter;

        parent::__construct('range_price_foliation');

        $this->setAttribute('method', 'post');

        $this->add(array(
            'name' => 'id',
            'type' => 'Hidden',
        ));

        $this->add(array(
            'name' => 'id_paper',
            'type' => 'select',
            'options' => array(
                'label' => 'Papier',
                'column-size' => 'sm-4',
                'label_attributes' => array('class' => 'col-sm-2'),
                'empty_option' => 'Wybierz papier',
                'value_options' => $this->getOptionPaper(),
            ),
            'attributes' => array(
                'class' => 'form-control',
            ),
        ));


        $this->add(array(
            'name' => 'id_size',
            'type' => 'select',
            'options' => array(
                'label' => 'Rozmiar papieru',
                'column-size' => 'sm-4',
                'label_attributes' => array('class' => 'col-sm-2'),
                'empty_option' => 'Wybierz rozmiar papieru',
                'value_options' => $this->getOptionPaperSize(),
            ),
            'attributes' => array(
                'class' => 'form-control',
            ),
        ));

        $this->add(array(
            'name' => 'range_min',
            'type' => 'Text',
            'options' => array(
                'label' => 'Zakres minimum',
                'column-size' => 'sm-4',
                'label_attributes' => array('class' => 'col-sm-2'),
            ),
            'attributes' => array(
                'class' => 'form-control',
            ),
        ));

        $this->add(array(
            'name' => 'range_max',
            'type' => 'Text',
            'options' => array(
                'label' => 'Zakres maximum',
                'column-size' => 'sm-4',
                'label_attributes' => array('class' => 'col-sm-2'),
            ),
            'attributes' => array(
                'class' => 'form-control',
            ),
        ));

        $this->add(array(
            'name' => 'price',
            'type' => 'Text',
            'options' => array(
                'label' => 'Cena za druk',
                'column-size' => 'sm-4',
                'label_attributes' => array('class' => 'col-sm-2'),
            ),
            'attributes' => array(
                'class' => 'form-control',
            ),
        ));

        $this->add(array(
            'name' => 'submit',
            'type' => 'Submit',
            'attributes' => array(
                'value' => 'Ok',
                'id' => 'submitbutton',
                'class' => 'btn btn-primary',
            ),
        ));
    }

    public function getOptionPaper() {

        $dbAdapter = $this->Adapter;
        $query = "SELECT id, name FROM material WHERE id_material_class = 1 ORDER BY name";
        $statement = $dbAdapter->query($query);

        $result = $statement->execute();

        $selectData = array();

        foreach ($result as $res) {

            $selectData[$res['id']] = $res['name'];
        }

        return $selectData;
    }

    public function getOptionPaperSize() {

        $dbAdapter = $this->Adapter;
        $query = "select id, value from public.material_features where id_feature = 2 order by id";
        $statement = $dbAdapter->query($query);

        $result = $statement->execute();

        $selectData = array();

        foreach ($result as $res) {

            $selectData[$res['id']] = $res['value'];
        }

        return $selectData;
    }

}
