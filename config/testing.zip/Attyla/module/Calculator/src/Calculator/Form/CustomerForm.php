<?php

/*
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 * 
 * Data zmian: 10-09-2015
 * 
 */

namespace Calculator\Form;

use Zend\Form\Form;

class CustomerForm extends Form {

    public function __construct($name = null) {

        parent::__construct('customers');

        $this->setAttribute('method', 'post');

        $this->add(array(
            'name' => 'id',
            'type' => 'Hidden',
        ));

        $this->add(array(
            'name' => 'name',
            'type' => 'Text',
            'options' => array(
                'label' => 'Imię',
                'column-size' => 'sm-4',
                'label_attributes' => array('class' => 'col-sm-2')
            ),
            'attributes' => array(
                'class' => 'form-control',
            ),
        ));

        $this->add(array(
            'name' => 'surname',
            'type' => 'Text',
            'options' => array(
                'label' => 'Nazwisko',
                'column-size' => 'sm-4',
                'label_attributes' => array('class' => 'col-sm-2')
            ),
            'attributes' => array(
                'class' => 'form-control',
            ),
        ));

        $this->add(array(
            'name' => 'firm',
            'type' => 'Text',
            'options' => array(
                'label' => 'Firma',
                'column-size' => 'sm-4',
                'label_attributes' => array('class' => 'col-sm-2')
            ),
            'attributes' => array(
                'class' => 'form-control',
            ),
        ));

        $this->add(array(
            'name' => 'email',
            'type' => 'Text',
            'options' => array(
                'label' => 'Email',
                'column-size' => 'sm-4',
                'label_attributes' => array('class' => 'col-sm-2')
            ),
            'attributes' => array(
                'class' => 'form-control',
            ),
        ));

        $this->add(array(
            'name' => 'submit',
            'type' => 'Submit',
            'attributes' => array(
                'value' => 'Ok',
                'id' => 'submitbutton',
                'class' => 'btn btn-primary',
            ),
        ));
    }

}
