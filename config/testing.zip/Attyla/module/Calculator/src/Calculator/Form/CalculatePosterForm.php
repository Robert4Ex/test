<?php

/*
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 * 
 * Data zmian: 04-03-2016
 * 
 */

namespace Calculator\Form;

use Zend\Form\Form;
use Zend\Db\Adapter\AdapterInterface;

class CalculatePosterForm extends Form {

    protected $Adapter;

    protected function setDbAdapter(AdapterInterface $dbAdapter) {

        $this->Adapter = $dbAdapter;
        return $this;
    }

    protected function getDbAdapter() {

        return $this->dbAdapter;
    }

    public function __construct(AdapterInterface $dbAdapter, $name = null) {

        $this->Adapter = $dbAdapter;

        parent::__construct('pricing_poster');

        //$this->setAttributes('class', 'form-vertical');

        $this->add(array(
            'name' => 'id',
            'type' => 'Hidden',
        ));

        $this->add(array(
            'name' => 'id_customer',
            'type' => 'select',
            'options' => array(
                'label' => 'Klient ',
                'empty_option' => 'Wybierz klienta',
                'value_options' => $this->getOptionCustomer(),
            ),
            'attributes' => array(
                'class' => 'form-control',
                'label_attributes' => array('class' => 'col-sm-2'),
            ),
        ));

        $this->add(array(
            'name' => 'id_paper',
            'type' => 'select',
            'options' => array(
                'label' => 'Papier',
                'empty_option' => 'Wybierz papier',
                'value_options' => $this->getOptionPaper(),
            ),
            'attributes' => array(
                'class' => 'form-control',
                'column-size' => 'sm-4',
                'label_attributes' => array('class' => 'col-sm-2')
            ),
        ));

//        $this->add(array(
//            'name' => 'id_printer',
//            'type' => 'select',
//            'options' => array(
//                'label' => 'Drukarka',
//                'empty_option' => 'Wybierz drukarkę',
//                'value_options' => $this->getOptionPrinter(),
//            ),
//            'attributes' => array(
//                'class' => 'form-control',
//                'column-size' => 'sm-4',
//                'label_attributes' => array('class' => 'col-sm-2')
//            ),
//        ));

        $this->add(array(
            'name' => 'id_size',
            'type' => 'select',
            'options' => array(
                'label' => 'Rozmiar papieru',
                'empty_option' => 'Wybierz rozmiar papieru',
                'value_options' => $this->getOptionPaperSize(),
            ),
            'attributes' => array(
                'class' => 'form-control',
                'column-size' => 'sm-4',
                'label_attributes' => array('class' => 'col-sm-2')
            ),
        ));

        $this->add(array(
            'name' => 'grammage',
            'type' => 'select',
            'options' => array(
                'label' => 'Gramatura',
                'empty_option' => 'Wybierz gramaturę',
                'value_options' => $this->getOptionGrammage(),
            ),
            'attributes' => array(
                'class' => 'form-control',
                'column-size' => 'sm-4',
                'label_attributes' => array('class' => 'col-sm-2')
            ),
        ));

        $this->add(array(
            'name' => 'paper_amount',
            'type' => 'Text',
            'options' => array(
                'label' => 'Nakład',
            ),
            'attributes' => array(
                'class' => 'form-control',
                'column-size' => 'sm-4',
                'label_attributes' => array('class' => 'col-sm-2')
            ),
        ));

        $this->add(array(
            'name' => 'project',
            'type' => 'Text',
            'options' => array(
                'label' => 'Projekt',
            ),
            'attributes' => array(
                'class' => 'form-control',
                'column-size' => 'sm-4',
                'label_attributes' => array('class' => 'col-sm-2')
            ),
        ));

        $this->add(array(
            'name' => 'print_type',
            'type' => 'select',
            'options' => array(
                'label' => 'Typ wydruku ',
                'empty_option' => 'Wybierz typ',
                'value_options' => $this->getOptionPrintType(),
            ),
            'attributes' => array(
                'class' => 'form-control',
                'column-size' => 'sm-4',
                'label_attributes' => array('class' => 'col-sm-2')
            ),
        ));

        $this->add(array(
            'name' => 'cutpack',
            'type' => 'checkbox',
            'options' => array(
                'label' => 'Cięcie',
                'column-size' => 'sm-4',
                'label_attributes' => array('class' => 'col-sm-2')
            ),
            'attributes' => array(
                'class' => 'checkbox inline',
            ),
        ));

        $this->add(array(
            'name' => 'diffi_cutpack',
            'type' => 'checkbox',
            'options' => array(
                'label' => 'Trudne cięcie',
                'column-size' => 'sm-4',
                'label_attributes' => array('class' => 'col-sm-2')
            ),
            'attributes' => array(
                'class' => 'checkbox inline',
            ),
        ));
        
        $this->add(array(
            'name' => 'package',
            'type' => 'checkbox',
            'options' => array(
                'label' => 'Pakowanie',
                'column-size' => 'sm-4',
                'label_attributes' => array('class' => 'col-sm-2')
            ),
            'attributes' => array(
                'class' => 'checkbox inline',
            ),
        ));
        
        $this->add(array(
            'name' => 'diffi_printing',
            'type' => 'checkbox',
            'options' => array(
                'label' => 'Trudny druk',
                'column-size' => 'sm-4',
                'label_attributes' => array('class' => 'col-sm-2')
            ),
            'attributes' => array(
                'class' => 'checkbox inline',
            ),
        ));

        $this->add(array(
            'name' => 'v_diffi_printing',
            'type' => 'checkbox',
            'options' => array(
                'label' => 'Bardzo trudny druk',
                'label_attributes' => array('class' => 'col-sm-2')
            ),
            'attributes' => array(
                'class' => 'checkbox inline',
            ),
        ));

        $this->add(array(
            'name' => 'submit',
            'type' => 'Submit',
            'attributes' => array(
                'value' => 'Ok',
                'id' => 'submitbutton',
                'class' => 'btn btn-primary',
            ),
        ));
    }

    public function getOptionCustomer() {

        $dbAdapter = $this->Adapter;
        $query = "SELECT id, surname || ' ' || name as name FROM public.customers order by surname";
        $statement = $dbAdapter->query($query);

        $result = $statement->execute();

        $selectData = array();

        foreach ($result as $res) {

            $selectData[$res['id']] = $res['name'];
        }

        return $selectData;
    }

    public function getOptionPaperSize() {

        $dbAdapter = $this->Adapter;
        $query = "select id, value from public.material_features where id_feature = 2 and id = 25 order by id";
        $statement = $dbAdapter->query($query);

        $result = $statement->execute();

        $selectData = array();

        foreach ($result as $res) {

            $selectData[$res['id']] = $res['value'];
        }

        return $selectData;
    }

    public function getOptionPaper() {

        $dbAdapter = $this->Adapter;
        $query = "SELECT id, name FROM material WHERE id_material_class = 1 ORDER BY name";
        $statement = $dbAdapter->query($query);

        $result = $statement->execute();

        $selectData = array();

        foreach ($result as $res) {

            $selectData[$res['id']] = $res['name'];
        }

        return $selectData;
    }

    public function getOptionPrintType() {

        $dbAdapter = $this->Adapter;
        $query = "select id, value from public.material_features where id_feature = 3 order by id";
        $statement = $dbAdapter->query($query);

        $result = $statement->execute();

        $selectData = array();

        foreach ($result as $res) {

            $selectData[$res['id']] = $res['value'];
        }

        return $selectData;
    }

    public function getOptionPrinter() {

        $dbAdapter = $this->Adapter;
        $query = "SELECT id, name FROM material WHERE id_material_class = 2 ORDER BY name";
        $statement = $dbAdapter->query($query);

        $result = $statement->execute();

        $selectData = array();

        foreach ($result as $res) {

            $selectData[$res['id']] = $res['name'];
        }

        return $selectData;
    }

        public function getOptionGrammage() {

        $dbAdapter = $this->Adapter;
        $query = "select id, value from public.material_features where id_feature = 10 order by id";
        $statement = $dbAdapter->query($query);

        $result = $statement->execute();

        $selectData = array();

        foreach ($result as $res) {

            $selectData[$res['id']] = $res['value'];
        }

        return $selectData;
    }
    
}
