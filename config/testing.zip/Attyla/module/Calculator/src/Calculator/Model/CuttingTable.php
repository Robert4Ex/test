<?php

/*
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 * 
 * Data zmian: 18-10-2015
 * 
 */

namespace Calculator\Model;

use Zend\Db\TableGateway\TableGateway;

class CuttingTable {

    protected $tableGateway;

    public function __construct(TableGateway $tableGateway) {

        $this->tableGateway = $tableGateway;
    }

    public function select() {

        $select = $this->tableGateway->getSql()->select();
        $select->columns(array('id', 'id_paper', 'id_size', 'range_min', 'range_max', 'price'));
        $select->join(array('MF' => 'material_features'), 'MF.id = range_price_cutting.id_size', array('size'=>'value'), 'left');
        $select->join(array('MM' => 'material'), 'MM.id = range_price_cutting.id_paper', array('paper'=>'name'), 'left');
        
        $resultset = $this->tableGateway->selectWith($select);

        return $resultset;
    }

   

}
