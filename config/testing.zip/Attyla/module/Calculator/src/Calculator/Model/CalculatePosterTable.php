<?php

/*
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 * 
 * Data zmian: 04-03-2016
 * 
 */

namespace Calculator\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Where;
use Calculator\Logic\PaperData;
use Calculator\Logic\PrinterData;
use Calculator\Logic\Dimensions;
use Calculator\Logic\CustomerData;
use Calculator\Logic\CuttingData;

class CalculatePosterTable {

// Metody główne

    protected $tableGateway;
    protected $pricing_poster_temporary = array();

    public function __construct(TableGateway $tableGateway) {

        $this->tableGateway = $tableGateway;
    }

    public function fetchAll() {

        $select = $this->tableGateway->getSql()->select();
        $select->columns(array('id', 'id_paper', 'id_size', 'paper_amount', 'stamp', 'project', 'cutpack', 'id_customer',
            'diffi_printing', 'v_diffi_printing', 'calculatedate', 'cost', 'price_per_sheet', 'print_type', 'paper_cost', 'waste', 'waste_cost'));
        $select->join(array('CC' => 'customers'), 'CC.id = pricing_poster.id_customer', array('surname' => 'surname', 'name' => 'name'), 'left');
        $select->join(array('MM' => 'material'), 'MM.id = pricing_poster.id_paper', array('paper' => 'name'), 'left');
        $select->join(array('MM2' => 'material'), 'MM2.id = pricing_poster.id_printer', array('printer' => 'name'), 'left');
        $select->join(array('MF' => 'material_features'), 'MF.id = pricing_poster.id_size', array('size' => 'value'), 'left');
        $select->join(array('MF2' => 'material_features'), 'MF2.id = pricing_poster.print_type', array('printType' => 'value'), 'left');
        $select->join(array('MF3' => 'material_features'), 'MF3.id = pricing_poster.grammage', array('grammage' => 'value'), 'left');
        $select->order('id');

        $resultset = $this->tableGateway->selectWith($select);

        return $resultset;
    }

    public function getOnePosterCalculate($id) {

        $rowset = $this->tableGateway->select(array('id' => (int) $id));
        $row = $rowset->current();

        // if (!$row)
        // throw new Exception ('Nie znalazłem rekordu');

        return $row;
    }

    public function getForOneCustomer($id_customer) {

        $rowset = $this->tableGateway->select(array('id_customer' => (int) $id_customer));
        $row = $rowset->current();

//        if (!$row) {
//
//            throw new Exception("Nie znaleziono kalkulacji dla klienta!");
//        }

        return $row;
    }

    public function selectCalculate(CalculatePoster $calculate) {

        $selectCalculate = $this->calculateCheck($calculate);

        return $selectCalculate;
    }

    public function addOne($id) {

        $adapter = $this->tableGateway->getAdapter();

        $userTable = new TableGateway('pricing_poster_temporary', $adapter);

        $sql = new Sql($this->tableGateway->adapter);

        $select = $sql->select();
        $select->from(array('pricing_poster_temporary' => 'pricing_poster_temporary'));
        $select->columns(array('id_customer', 'id_paper', 'id_size', 'paper_amount', 'stamp'
            , 'project', 'cutpack', 'diffi_printing', 'v_diffi_printing', 'calculatedate', 'cost'
            , 'price_per_sheet', 'print_type', 'print_type', 'paper_cost', 'grammage', 'waste', 'waste_cost'
            , 'diffi_cutpack', 'package', 'status'));
        $select->where(array('id_row' => $id));
        $select->order('id_row desc');
        $select->limit(1);

        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        foreach ($result as $res) {
            $this->pricing_poster_temporary[] = $res;
        }

        $this->tableGateway->insert($this->pricing_poster_temporary[0]);

        $userTable->delete(array());
    }

    public function save(array $calculate) {

        $adapter = $this->tableGateway->getAdapter();

        $userTable = new TableGateway('pricing_poster_temporary', $adapter);

        foreach ($calculate as $calc) {

            $data = array(
                'id_customer' => $calc[0]['id_customer'],
                'id_paper' => $calc[0]['id_paper'],
                'id_size' => $calc[0]['id_size'],
                'id_printer' => $calc[0]['id_printer'],
                'paper_amount' => $calc[0]['paper_amount'],
                'stamp' => $calc[0]['stamp'],
                'project' => $calc[0]['project'],
                'print_type' => $calc[0]['print_type'],
                'cutpack' => $calc[0]['cutpack'],
                'diffi_printing' => $calc[0]['diffi_printing'],
                'v_diffi_printing' => $calc[0]['v_diffi_printing'],
                'price_per_sheet' => $calc[0]['price_per_sheet'],
                'grammage' => $calc[0]['grammage'],
                'cost' => $calc[0]['cost'],
                'price_per_sheet' => $calc[0]['price_per_sheet'],
                'stamp' => $calc[0]['stamp'],
                'paper_cost' => $calc[0]['paper_cost'],
                'waste' => $calc[0]['waste'],
                'waste_cost' => $calc[0]['waste_cost'],
                'id_row' => $calc[0]['id_calculate'],
            );

            $userTable->insert($data);
        }
    }

    public function delete($id) {

        //Kasowanie wpisów kalkulacji dla plakatu

        $this->tableGateway->delete(array('id' => (int) $id));
    }

    public function deleteAll() {

        //Kasowanie wszystkich wpisów kalkulacji dla plakatu
        // $this->tableGateway->delete(array());
    }

//------------------------------    
// Metody dodatkowe wykorzystywane w metodach głównych


    public function calculateCheck(CalculatePoster $calculate) {

        $data = array(
            'id_customer' => $calculate->id_customer,
            'id_paper' => $calculate->id_paper,
            'id_size' => $calculate->id_size,
            'id_printer' => $calculate->id_printer,
            'paper_amount' => $calculate->paper_amount,
            'stamp' => $calculate->stamp,
            'project' => number_format($calculate->project, 2, '.', ''),
            'print_type' => $calculate->print_type,
            'cutpack' => $calculate->cutpack,
            'diffi_printing' => $calculate->diffi_printing,
            'v_diffi_printing' => $calculate->v_diffi_printing,
            'price_per_sheet' => $calculate->price_per_sheet,
            'grammage' => $calculate->grammage,
            'name' => $calculate->name,
            'surname' => $calculate->surname,
            'package' => $calculate->package,
            'diffi_cutpack' => $calculate->diffi_cutpack,
        );



        $sql = new Sql($this->tableGateway->adapter);
//-----
        $printer = new Dimensions();

//-----        
        $printerDatas = new PrinterData();
        // $printerData = $printerDatas->matrixCostPrimo($sql, $data['id_printer'], $data['print_type'], $printerDimData['id_printer_paper']);
        $paperData = $printerDatas->matrixCostPrimo($sql, $data['id_printer'], $data['print_type'], $data['id_size']);
        $printerName = $printerDatas->printerName($sql, $data['id_printer']);
        $printTypeName = $printerDatas->printTypeName($sql, $data['print_type']);

//      $data['printerName'] = $printerName['name'];
        $data['printTypeName'] = $printTypeName['printTypeName'];
//-----        
        $paperDatas = new PaperData();
        $grammageData = $paperDatas->grammage($sql, $data['grammage']);
        $paperNameData = $paperDatas->paperName($sql, $data['id_paper']);
        $paperSizeData = $paperDatas->paperSize($sql, $data['id_size']);

        $data['paperSize'] = $paperSizeData['paperSize'];
        $data['paperName'] = $paperNameData['name'];
        $data['grammageData'] = $grammageData[0];

//-----
        $allprinter = $printerDatas->getAllPrinter($sql);
//-----        
        $customerData = new CustomerData();
        $customer = $customerData->getCustomer($sql, $data['id_customer']);

        $data['surname'] = $customer['surname'];
        $data['name'] = $customer['name'];
//-----
//-----        
        $calculacja = array();

        $i = 0;

        foreach ($allprinter as $all) {

            $data['id_printer'] = $all['id'];
            $data['printerName'] = $all['name'];

            $printerDimData = $printer->getPrinterPaper($sql, $data['id_printer']);
            $printerData = $printerDatas->matrixCostPrimo($sql, $data['id_printer'], $data['print_type'], $printerDimData['id_printer_paper']);

            //-----        
            $select = $sql->select();
            $select->from(array('MF' => 'material_features'));
            $select->columns(array('id' => 'id_feature_base'));

            $where = new Where();
            $where->equalTo('id_feature', 7);
            $where->lessThanOrEqualTo('value', $printerData[0]);
            $where->greaterThanOrEqualTo('value', $paperData[0]);

            $select->where($where);
            $select->order('id');

            $statement = $sql->prepareStatementForSqlObject($select);
            $result = $statement->execute();

            $paperData = array();

            foreach ($result as $id) {

                $paperData[] = (int) $id['id'];
            }


            foreach ($paperData as $id) {

                //var_dump($data['id_printer']);

                $paperSize = $paperDatas->paperSize($sql, $id);


                $array = $this->calculatePoster($id, $data['id_paper'], $data['id_size'], $data['paper_amount'], $data['project'], $data['cutpack'], $data['diffi_printing'], $data['v_diffi_printing'], $data['print_type'], $data['id_printer'], $data['grammage'], $data['package']);
                $data['cost'] = $array['cost'];
                $data['price_per_sheet'] = $array['price'];
                $data['stamp'] = $array['matrixCost'];
                $data['paper_cost'] = $array['paperPrice'];
                $data['waste'] = $array['waste'];
                $data['waste_cost'] = $array['waste_cost'];
                $data['cutPackCost'] = $array['cutPackCost'];
                $data['v_diffi_printing_add'] = $array['v_diffi_printing_add'];
                $data['diffi_printing_add'] = $array['diffi_printing_add'];
                $data['workCost'] = $array['workCost'];
                $data['orientationPaper'] = $array['orientationPaper'];
                $data['sheetNumber'] = $array['sheetNumber'];
                $data['paperNameUse'] = $paperSize['paperSize'];
                $data['id'] = $id;
                $data['packageWeight'] = $array['packageWeight'];
                $data['packagePrice'] = $array['packagePrice'];
                $data['packageCount'] = $array['packageCount'];
                $data['packageName'] = $array['packageName'];

                $data['id_calculate'] = $i;

                if ($data['waste'] == '0.00') {

                    $calculacja[$i][0] = $data;

                    $i++;
                }
            }
        }

        return $calculacja;
    }

    //------------------------------    
// Metody dodatkowe wykorzystywane w metodach głównych

    public function calculatePoster($id, $id_paper, $id_size, $paper_amount, $project, $cutpack, $diffi_printing, $v_diffi_printing, $print_type, $id_printer, $id_grammage, $package) {

        $paper_amount_with_diff_print = $paper_amount;

        //kalkulacja wyceny plakatu
        // obiekt SQL do wszystkich zapytań
        $sql = new Sql($this->tableGateway->adapter);

        // $dimensionData - tablica z wymiarami plakatu wybranego przez klienta
        // $matrixData - tablica z ceną matrycy dla danej drukarki
        // $paperData - tablica z ceną za kg papieru wybranego przez klienta 
        // $printerData - tablica z rozmiarem drukarki i ilością matryc dla danego typu wydruku
        // $grammageData - tablica z gramaturą wybraną przez klienta
        // $dimension - tablica z możliwą ilością plakatów nadrukowanych na jednym arkuszu wybranej drukarki oraz z % odpadem
        // $waste_costs - tablica z wagą, ceną i ceną odpadu jednego arkusza papieru wybranej drukarki
        // $paperCosts - tablica z wagą i ceną papieru jednego plakatu wybranego przez klienta
        // wyliczenie ilości plakatów na arkusz i odpadu papieru       
        //rozmiar drukarki //cena jednej matrycy // ilość matryc dla danego typu wydruku

        $printerDatas = new PrinterData();
        $printerData = $printerDatas->matrixCostPrimo($sql, $id_printer, $print_type, $id);

        //wymiary plakatu wybranego przez klienta

        $dimensionDatas = new Dimensions();
        $dimensionData = $dimensionDatas->getCustomerPaper($sql, $id_size);
        $printerPaperData = $dimensionDatas->getPrinterPaper($sql, $id_printer);
        $dimension = $dimensionDatas->paperCheck($dimensionData['0'], $dimensionData['1'], $printerData['0'], $printerData['1']);

        //gramatura

        $paperDatas = new PaperData();
        $grammageData = $paperDatas->grammage($sql, $id_grammage);
        $paperData = $paperDatas->paperWeightCost($sql, $id_paper);
        $waste_costs = $paperDatas->paperCustomerCost($paperData['0'], $printerData['0'], $printerData['1'], $grammageData['0'], $dimension['odpad']);
        $paperCosts = $paperDatas->paperCustomerCost($paperData['0'], $dimensionData['0'], $dimensionData['1'], $grammageData['0']);
        $printData = $paperDatas->printingCostForPaper($sql, $id_paper, $printerPaperData['id_printer_paper'], $paper_amount, $print_type);
        // $cuttingData = $paperDatas->cuttingCostForPaper($sql, $id_size, $paper_amount);  
        $packingData = $paperDatas->packingCostForPaper($sql, $paperCosts['weight'], $paper_amount);

        //zwiększenie ilości zamówionych plakatów w zależności czy został określony trudny lub bardzo trudny druk
        if ($v_diffi_printing != 0) { //bardzo trudny druk
            $array['v_diffi_printing_add'] = ceil(($printData['0']['v_diffi_printing'] * $paper_amount) / 100);
            $array['diffi_printing_add'] = '0';
            $paper_amount_with_diff_print = $paper_amount + ceil(($printData['0']['v_diffi_printing'] * $paper_amount) / 100);
        } else if ($diffi_printing != 0) { //trudny druk
            $array['diffi_printing_add'] = ceil(($printData['0']['diffi_printing'] * $paper_amount) / 100);
            $array['v_diffi_printing_add'] = '0';
            $paper_amount_with_diff_print = $paper_amount + ceil(($printData['0']['diffi_printing'] * $paper_amount) / 100);
        } else {

            $array['diffi_printing_add'] = '0';
            $array['v_diffi_printing_add'] = '0';
        }

        $printingData = $paperDatas->PrintingCostForPaper($sql, $id_paper, $printerPaperData['id_printer_paper'], $paper_amount_with_diff_print, $print_type, $dimension['iloscArkuszy']);

        //Obliczenie ilości arkuszy papieru w zależności on ilości nadrukowanych plakatów na jednym arkuszu
        //Ilość zamówionych plakatów dzielimy na iość plakatów zmieszczonych na jednym arkuszu maksymalnym dla danej maszyny
        $paper_sheet = ceil($paper_amount_with_diff_print / $dimension['iloscArkuszy']);

        //Obliczenie ceny matryc dla danej maszyny drukującej
        $array['matrixCost'] = number_format(($printerData['matrixData'] * $printerData['matrix']), 2, '.', '');

        //cena nadruku arkusza

        $array['price'] = number_format($printingData['0']['price'], 3, '.', '');

        //wyliczenie ceny zlecenia wydruku plakatów
        $cost = ($printingData['0']['price'] * $paper_sheet) + $array['matrixCost'] + $project + ($paperCosts['paperPrice'] * $paper_amount_with_diff_print);

        //doliczenie do ceny kalkulacji ceny za cięcie

        $cutting = new CuttingData($sql);
        $cutting->setGramageData((int) $grammageData);
        $cutting->setPaperAmount((int) $paper_amount);
        $cutting->setRowCountHorizontally($dimension['iloscRzedowPionowo']);
        $cutting->setRowCountVertically($dimension['iloscRzedowPoziomo']);

        $cutting->getMaxPaperToCut();
        $cutting->getOneCuttingPrice();

        $cuttingPrice = $cutting->getCuttingPrice();

        //var_dump($cuttingPrice);

        $cost += $cuttingPrice['CuttingPrice'];

        //dane pakowania


        if ($package == 1) {

            $cost += ($packingData[0]['price'] * $packingData['packageCount']);
            $array['packageCount'] = $packingData['packageCount'];
            $array['packageWeight'] = $packingData['packageWeight'];
            $array['packagePrice'] = ($packingData[0]['price'] * $packingData['packageCount']);
            $array['packageName'] = '/' . $packingData['packageName'];
        } else {

            $array['packageCount'] = 0;
            $array['packageWeight'] = 0;
            $array['packagePrice'] = 0.00;
            $array['packageName'] = '';
        }

        $array['cutPackCost'] = $cuttingPrice['cuttingCount']
                . '/' . $cuttingPrice['packCount']
                . '/' . $cuttingPrice['paperCountToCut']
                . '/' . number_format($cuttingPrice['CuttingPrice'], 2, '.', '');

        $array['cost'] = number_format($cost, 2, '.', ''); //kwota kalkulacji
        $array['paperPrice'] = number_format($paperCosts['paperPrice'], 3, '.', ''); //cena papieru
        $array['waste'] = number_format($dimension['odpad'], 2, '.', ''); //% odpad - papier niezadrukowany
        $array['waste_cost'] = number_format(($paper_sheet * $waste_costs['waste_cost']), 2, '.', ''); //koszt odpadu z arkusza użytego w maszynie
        $array['workCost'] = number_format((($paper_sheet * $waste_costs['waste_cost']) + $cost), 2, '.', '');
        $array['orientationPaper'] = $dimension['orientacja'];
        $array['sheetNumber'] = $dimension['iloscArkuszy'];

        return $array;
    }

}
