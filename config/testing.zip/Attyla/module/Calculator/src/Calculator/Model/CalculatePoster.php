<?php

/*
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 * 
 * Data zmian: 18-10-2015
 * 
 */

namespace Calculator\Model;

class CalculatePoster {

    public $id;
    public $surname;
    public $name;
    public $id_customer;
    public $id_paper;
    public $id_size;
    public $size;
    public $paper_amount;
    public $stamp;
    public $project;
    public $cutpack;
    public $diffi_cutpack;
    public $package;
    public $cost;
    public $print_type;
    public $printing_type;
    public $diffi_printing;
    public $v_diffi_printing;
    public $calculatedate;
    public $price_per_sheet;
    public $value;
    public $printer;
    public $paper;
    public $id_printer;
    public $printType;
    public $paper_cost;
    public $grammage;
    public $waste;
    public $waste_cost;
    public $id_calculate;
    
    public function exchangeArray($d) {
        $this->id = (!empty($d['id'])) ? $d['id'] : 0;
        $this->calculatedate = (!empty($d['calculatedate'])) ? $d['calculatedate'] : 0;
        $this->id_customer = (!empty($d['id_customer'])) ? $d['id_customer'] : 0;
        $this->surname = (!empty($d['surname'])) ? $d['surname'] : 0;
        $this->name = (!empty($d['name'])) ? $d['name'] : 0;
        $this->id_paper = (!empty($d['id_paper'])) ? $d['id_paper'] : null;
        $this->size = (!empty($d['size'])) ? $d['size'] : null;
        $this->id_size = (!empty($d['id_size'])) ? $d['id_size'] : null;
        $this->paper_amount = (!empty($d['paper_amount'])) ? $d['paper_amount'] : 0;
        $this->stamp = (!empty($d['stamp'])) ? $d['stamp'] : 0.00;
        $this->project = (!empty($d['project'])) ? $d['project'] : 0.00;
        $this->cutpack = (!empty($d['cutpack'])) ? $d['cutpack'] : 0;
        $this->diffi_cutpack = (!empty($d['diffi_cutpack'])) ? $d['diffi_cutpack'] : 0;
        $this->package = (!empty($d['package'])) ? $d['package'] : 0;
        $this->print_type = (!empty($d['print_type'])) ? $d['print_type'] : 1;
        $this->printing_type = (!empty($d['printing_type'])) ? $d['printing_type'] : null;
        $this->diffi_printing = (!empty($d['diffi_printing'])) ? $d['diffi_printing'] : 0;
        $this->v_diffi_printing = (!empty($d['v_diffi_printing'])) ? $d['v_diffi_printing'] : 0;
        $this->cost = (!empty($d['cost'])) ? $d['cost'] : 0;
        $this->price_per_sheet = (!empty($d['price_per_sheet'])) ? $d['price_per_sheet'] : 0;
        $this->value = (!empty($d['value'])) ? $d['value'] : null;
        $this->printer = (!empty($d['printer'])) ? $d['printer'] : null;
        $this->paper = (!empty($d['paper'])) ? $d['paper'] : null;
        $this->printType = (!empty($d['printType'])) ? $d['printType'] : null;
        $this->id_printer = (!empty($d['id_printer'])) ? $d['id_printer'] : 0;
        $this->paper_cost = (!empty($d['paper_cost'])) ? $d['paper_cost'] : 0;
        $this->grammage = (!empty($d['grammage'])) ? $d['grammage'] : 0;
        $this->waste = (!empty($d['waste'])) ? $d['waste'] : 0;
        $this->waste_cost = (!empty($d['waste_cost'])) ? $d['waste_cost'] : 0;
        $this->id_calculate = (!empty($d['id_calculate'])) ? $d['id_calculate'] : 0;
        }

    public function getArrayCopy() {

        return get_object_vars($this);
    }

}
