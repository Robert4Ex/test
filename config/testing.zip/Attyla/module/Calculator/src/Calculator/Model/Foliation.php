<?php

/*
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 * 
 * Data zmian: 10-09-2015
 * 
 */

namespace Calculator\Model;

class Foliation {

    public $id;
    public $id_paper;
    public $id_size;
    public $range_min;
    public $range_max;
    public $price;
    public $value;
    public $paper;
    public $size;

    public function exchangeArray($d) {
        $this->id = (!empty($d['id'])) ? $d['id'] : null;
        $this->id_paper = (!empty($d['id_paper'])) ? $d['id_paper'] : null;
        $this->id_size = (!empty($d['id_size'])) ? $d['id_size'] : null;
        $this->range_min = (!empty($d['range_min'])) ? $d['range_min'] : null;
        $this->range_max = (!empty($d['range_max'])) ? $d['range_max'] : null;
        $this->price = (!empty($d['price'])) ? $d['price'] : null;
        $this->value = (!empty($d['value'])) ? $d['value'] : null;
        $this->paper = (!empty($d['paper'])) ? $d['paper'] : null;
        $this->size = (!empty($d['size'])) ? $d['size'] : null;
    }

    public function getArrayCopy() {

        return get_object_vars($this);
    }

}
