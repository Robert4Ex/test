<?php

/*
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 */

namespace Calculator\Model;

class Customer {

    public $id;
    public $name;
    public $surname;
    public $firm;
    public $email;

    public function exchangeArray($d) {
        $this->id = (!empty($d['id'])) ? $d['id'] : null;
        $this->name = (!empty($d['name'])) ? $d['name'] : null;
        $this->surname = (!empty($d['surname'])) ? $d['surname'] : null;
        $this->firm = (!empty($d['firm'])) ? $d['firm'] : null;
        $this->email = (!empty($d['email'])) ? $d['email'] : null;
    }

    public function getArrayCopy() {

        return get_object_vars($this);
    }

}
