<?php

/* 
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 */

namespace Calculator\Model;

class PriceSettingsPaper {
    
    
    public $id_material;
    public $name;
    public $value;
    public $id;
    public $id_material_class;


    public function exchangeArray($d) {
        $this->id_material = (!empty($d['id_material'])) ? $d['id_material'] : null;
        $this->name = (!empty($d['name'])) ? $d['name'] : null;
        $this->value = (!empty($d['value'])) ? $d['value'] : null;
        $this->id = (!empty($d['id'])) ? $d['id'] : null;
        $this->id_material_class = (!empty($d['id_material_class'])) ? $d['id_material_class'] : null;

    }

    public function getArrayCopy() {

        return get_object_vars($this);
    }
    
    
}