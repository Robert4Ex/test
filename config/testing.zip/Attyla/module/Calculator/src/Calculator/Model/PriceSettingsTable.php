<?php

/*
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 */

namespace Calculator\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Where;

class PriceSettingsTable {

    protected $tableGateway;
    protected $sql;
    
    public $resul = array();

    public function __construct(TableGateway $tableGateway) {

        $this->tableGateway = $tableGateway;
        $this->sql = new Sql($this->tableGateway->adapter);
    }

    public function getAllPaperPrice() {

        $select = $this->tableGateway->getSql()->select();
        $select->columns(array('id_material', 'value'));
        $select->join(array('MAT' => 'material'), 'MAT.id = material_features.id_material', array('name' => 'name'), 'left');
        $select->order('MAT.name');
        $select->where('id_feature = 11');

        $resultset = $this->tableGateway->selectWith($select);

        return $resultset;
    }

    public function getAllMatrixPrice() {

        $select = $this->tableGateway->getSql()->select();
        $select->columns(array('id_material', 'value'));
        $select->join(array('MAT' => 'material'), 'MAT.id = material_features.id_material', array('name' => 'name'), 'left');
        $select->order('MAT.name');
        $select->where('id_feature = 9');

        $resultset = $this->tableGateway->selectWith($select);
        
        return $resultset;
    }

    public function getAllCourierPrice() {

        $select = $this->sql->select();
        $select->from(array('v_getAllCourierPrice' => 'v_getAllCourierPrice'));
        $statement = $this->sql->prepareStatementForSqlObject($select);
        $resultset = $statement->execute();
        
        $rows = array();
        
        $rows = new \Zend\Db\ResultSet\ResultSet();
        
        return $rows->initialize($resultset)->toArray();
    
    }

}
