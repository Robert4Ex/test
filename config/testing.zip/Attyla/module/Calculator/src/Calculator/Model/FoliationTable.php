<?php

/*
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 * 
 * Data zmian: 18-10-2015
 * 
 */

namespace Calculator\Model;

use Zend\Db\TableGateway\TableGateway;

class FoliationTable {

    protected $tableGateway;

    public function __construct(TableGateway $tableGateway) {

        $this->tableGateway = $tableGateway;
    }

    public function select() {

        $select = $this->tableGateway->getSql()->select();
        $select->columns(array('id', 'id_paper', 'id_size', 'range_min', 'range_max', 'price'));
        $select->join(array('MF' => 'material_features'), 'MF.id = range_price_foliation.id_size', array('size'=>'value'), 'left');
        $select->join(array('MM' => 'material'), 'MM.id = range_price_foliation.id_paper', array('paper'=>'name'), 'left');
        $resultset = $this->tableGateway->selectWith($select);

        return $resultset;
    }

    public function get($id) {
        $rowset = $this->tableGateway->select(array('id' => (int) $id));

        $row = $rowset->current();

        // if (!$row)
        // throw new Exception ('Nie znalazłem rekordu');

        return $row;
    }

    public function save(Foliation $a) {

        $id = (int) $a->id;
        $data = array(
            'id_paper' => $a->id_paper,
            'id_size' => $a->id_size,
            'range_min' => $a->range_min,
            'range_max' => $a->range_max,
            'price' => $a->price,
        );


        if (0 == $id) {
            $this->tableGateway->insert($data);
        } else {
            $this->tableGateway->update($data, array('id' => $id));
        }
    }

    public function remove($id) {

        $this->tableGateway->delete(array('id' => (int) $id));
    }

}
