<?php

/*
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 * 
 * Data zmian: 18-10-2015
 * 
 */

namespace Calculator\Model;

use Zend\InputFilter\InputFilter;

class Range {

    public $id;
    public $id_paper;
    public $id_size;
    public $value;
    public $range_min;
    public $range_max;
    public $price;
    public $print_type;
    public $printing_type;
    public $diffi_printing;
    public $v_diffi_printing;
    public $cutpack;
    public $paper;
    public $size;

    public function exchangeArray($d) {
        $this->id = (!empty($d['id'])) ? $d['id'] : null;
        $this->id_paper = (!empty($d['id_paper'])) ? $d['id_paper'] : null;
        $this->id_size = (!empty($d['id_size'])) ? $d['id_size'] : null;
        $this->range_min = (!empty($d['range_min'])) ? $d['range_min'] : null;
        $this->range_max = (!empty($d['range_max'])) ? $d['range_max'] : null;
        $this->price = (!empty($d['price'])) ? $d['price'] : null;
        $this->print_type = (!empty($d['print_type'])) ? $d['print_type'] : '4-0';
        $this->printing_type = (!empty($d['printing_type'])) ? $d['printing_type'] : 1;
        $this->diffi_printing = (!empty($d['diffi_printing'])) ? $d['diffi_printing'] : 0;
        $this->v_diffi_printing = (!empty($d['v_diffi_printing'])) ? $d['v_diffi_printing'] : 0;
        $this->cutpack = (!empty($d['cutpack'])) ? $d['cutpack'] : 0;
        $this->value = (!empty($d['value'])) ? $d['value'] : 0;
        $this->paper = (!empty($d['paper'])) ? $d['paper'] : 0;
        $this->size = (!empty($d['size'])) ? $d['size'] : 0;
    }

    public function setInputFilter(InputFilterInterface $inputFilter) {
        throw new Exception("Nie korzystamy");
    }

    protected $inputFilter;

    public function getInputFilter() {



        if (!$this->inputFilter) {

            $inputFilter = new InputFilter();

            $inputFilter->add(array(
                'name' => 'id',
                'required' => false,
                'filters' => array(
                    array('name' => 'Int'),
                ),
            ));

            $inputFilter->add(array(
                'name' => 'id_paper',
                'required' => true,
                'filters' => array(
                    array('name' => 'Int'),
                ),
            ));

            $inputFilter->add(array(
                'name' => 'id_size',
                'required' => true,
                'filters' => array(
                    array('name' => 'Int'),
                ),
            ));

            $inputFilter->add(array(
                'name' => 'range_min',
                'required' => true,
                'filters' => array(
                    array('name' => 'Int'),
                ),
            ));

            $inputFilter->add(array(
                'name' => 'range_max',
                'required' => true,
                'filters' => array(
                    array('name' => 'Int'),
                ),
            ));



            $this->inputFilter = $inputFilter;
        }
        return $this->inputFilter;
    }

    public function getArrayCopy() {

        return get_object_vars($this);
    }

}
