<?php

/*
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 */

namespace Calculator\Logic;

class CuttingData {

    protected $_grammageData;
    protected $_paperAmount;
    protected $_sql;
    protected $_rowCountVertically;
    protected $_rowCountHorizontally;
    protected $_returnOneCuttingPrice;
    protected $_returnMaxPaperToCut;
    protected $_returnCuttingPrice = array();


    public function __construct($sql) {

        $this->_sql = $sql;
    }

    public function setGramageData($grammageData) {

        if (!is_integer($grammageData)) {

            trigger_error('Błędna gramatura');
        } else {

            $this->_grammageData = $grammageData;
        }
    }

    public function setPaperAmount($paperAmount) {

        if (!is_integer($paperAmount)) {

            trigger_error('Błędna ilość kartek');
        } else {

            $this->_paperAmount = $paperAmount;
        }
    }

    public function setRowCountVertically($rowCountVertically) {
        
        if (0 == ($rowCountVertically)) {

            trigger_error('Błędna ilość wierszy pionowo');
        } else {

            $this->_rowCountVertically = $rowCountVertically;
        }
    }

    public function setRowCountHorizontally($rowCountHorizontally) {

        if (0 == ($rowCountHorizontally)) {

            trigger_error('Błędna ilość wierszy poziomo');
        } else {

            $this->_rowCountHorizontally = $rowCountHorizontally;
        }
    }
    
    public function getOneCuttingPrice() {

        $this->_paperAmount = $this->_paperAmount / $this->_rowCountHorizontally / $this->_rowCountVertically;
        
        $select = $this->_sql->select();
        $select->from(array('RPC' => 'range_price_cutting'));
        $select->columns(array('price'));
        $select->where->lessThanOrEqualTo('range_min', (ceil($this->_paperAmount / ceil($this->_paperAmount / $this->_returnMaxPaperToCut))));
        $select->where->greaterThanOrEqualTo('range_max', (ceil($this->_paperAmount / ceil($this->_paperAmount / $this->_returnMaxPaperToCut))));

        $statement = $this->_sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        foreach ($result as $res) {

            $this->_returnOneCuttingPrice = (float) $res['price'];
        }
        
        return $this->_returnOneCuttingPrice;
    }

    public function getMaxPaperToCut() {

        $select = $this->_sql->select();
        $select->from(array('RGP' => 'range_grammage_pages'));
        $select->columns(array('pages_amount'));
        $select->where->lessThanOrEqualTo('grammage_min', $this->_grammageData);
        $select->where->greaterThanOrEqualTo('grammage_max', $this->_grammageData);

        $statement = $this->_sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        foreach ($result as $res) {

            $this->_returnMaxPaperToCut = (float) $res['pages_amount'];
        }

        if (is_null($this->_returnMaxPaperToCut)) {

            trigger_error('Brak danych o cenie dla tej ilości kartek');
        }
        
        return $this->_returnMaxPaperToCut;
    }
    
    public function getCuttingPrice() {
        
        $this->_returnCuttingPrice['CuttingPrice'] = (float) ((($this->_rowCountHorizontally * 2) 
                                                    + ($this->_rowCountVertically * 2)) 
                                                    * ceil($this->_paperAmount / $this->_returnMaxPaperToCut)
                                                    * $this->_returnOneCuttingPrice);
        $this->_returnCuttingPrice['packCount'] = (integer) ceil($this->_paperAmount / $this->_returnMaxPaperToCut);
        $this->_returnCuttingPrice['paperCountToCut'] = (integer) ceil($this->_paperAmount / ceil($this->_paperAmount / $this->_returnMaxPaperToCut));
        $this->_returnCuttingPrice['cuttingCount'] = (integer) (($this->_rowCountHorizontally * 2) 
                                                                + ($this->_rowCountVertically * 2));
        
        return $this->_returnCuttingPrice;
    }

}
