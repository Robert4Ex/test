<?php

/*
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 * 
 * Data zmian 04-03-2016
 * 
 */

namespace Calculator\Logic;

use Zend\Db\Sql\Where;

class PaperData {

    public $paperCustomerCost = array();
    public $paperWeightCost = array();
    public $grammage = array();
    public $paperName = array();
    public $paperSize = array();
    public $printingCostForPaper = array();
    public $cuttingCostForPaper = array();
    public $packingCostForPaper = array();

    public function paperCustomerCost($weightCost, $heigh, $width, $grammage, $waste = null) {

        $weight = round((($heigh / 1000 * $width / 1000 * $grammage / 1000) * 1000), 2);

        $price = round($weight / 1000 * $weightCost, 3);

        $this->paperCustomerCost = array('weight' => $weight, 'paperPrice' => $price);

        if ($waste >= 0) {

            $waste_cost = ($price * $waste) / 100;
            $this->paperCustomerCost['waste_cost'] = round($waste_cost, 2);
        }

        
        
        return $this->paperCustomerCost;
    }

    public function paperWeightCost($sql, $id_paper) {

        $select = $sql->select();
        $select->from(array('MF' => 'material_features'));
        $select->columns(array('value'));
        $select->join(array('MM' => 'material'), 'MF.id_material = MM.id', array(), 'right');
        $select->where(array('MM.id' => $id_paper));
        
        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        foreach ($result as $res) {

            $this->paperWeightCost[] = (float) $res['value'];
        }
        
        return $this->paperWeightCost;
    }

    
    public function grammage($sql, $id_grammage) {
        


        $select = $sql->select();
        $select->from(array('MF' => 'material_features'));
        $select->columns(array('value'));
        $select->join(array('MF2' => 'material_features'), 'MF.id_feature_base = MF2.id', array(), 'left');
        $select->where(array('MF2.id' => $id_grammage));

        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

            foreach ($result as $res) {

                $this->grammage[] = (int) $res['value'];
            }

        return $this->grammage;
        
    }

    public function paperName($sql, $id_paper) {

        $select = $sql->select();
        $select->from(array('material' => 'material'));
        $select->columns(array('name'));
        $select->where(array('id' => $id_paper, 'id_material_class' => 1));

        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        foreach ($result as $res) {
            $this->paperName['name'] = $res['name'];
        }

        return $this->paperName;
    }

    public function paperSize($sql, $id_size) {

        $select = $sql->select();
        $select->from(array('MF' => 'material_features'));
        $select->columns(array('value'));
        $select->where(array('id' => $id_size, 'id_material_class' => 1));

        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        foreach ($result as $res) {
            $this->paperSize['paperSize'] = $res['value'];
        }

        return $this->paperSize;
    }

    public function printingCostForPaper($sql, $id_paper, $id_size, $paper_amount, $print_type, $amountOnPaper = 1) {

        //Pobieranie kosztu wydruku dla danego papieru z tabeli range_price_printing
        //Koszt wydruku pobieramy dla maksymalnego arkusza drukowanego w danej maszynie 


        
        $paperAmount = ceil($paper_amount / $amountOnPaper);

        $select = $sql->select();
        $select->from(array('PPR' => 'range_price_printing'));

        $where = new Where();
    //    $where->equalTo('id_paper', $id_paper);
        $where->equalTo('id_size', $id_size);
        $where->equalTo('print_type', $print_type);
        $where->lessThanOrEqualTo('range_min', $paperAmount);
        $where->greaterThanOrEqualTo('range_max', $paperAmount);

        $select->where($where);
        
        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        
        foreach ($result as $res) {

            $this->printingCostForPaper[] = $res;
        }
        

        
        return $this->printingCostForPaper;
    }


    public function packingCostForPaper($sql, $weig, $paper_amount) {

        //Pobieranie kosztu pakowania i ilości paczek dla danej wagi papieru z tabeli range_price_packing
        
        $weight = round($weig*$paper_amount/1000, 2);
        
        do {

            $select = $sql->select();
            $select->from(array('RPP' => 'range_price_packing'));
 
            $where = new Where();
            $where->lessThanOrEqualTo('weight_min', $weight);
            $where->greaterThanOrEqualTo('weight_max', $weight);

            $select->where($where);

            $statement = $sql->prepareStatementForSqlObject($select);
            $result = $statement->execute();
            
            foreach ($result as $res) {

                $this->packingCostForPaper[] = $res;
            }

            $weight = round($weight / 2, 2);
            
            } while ($this->packingCostForPaper == NULL);

            $select = $sql->select();
            $select->from(array('MAT' => 'material'));
            $select->columns(array('name'));
            
            $where = new Where();
            $where->EqualTo('id', $this->packingCostForPaper[0]['id_material']);
           

            $select->where($where);

            $statement = $sql->prepareStatementForSqlObject($select);
            $result = $statement->execute();
            
            foreach ($result as $res) {

                $this->packingCostForPaper['packageName'] = $res['name'];
            }
        
       
            
        $packageCount = ceil($weig * $paper_amount/ 1000 / $this->packingCostForPaper[0]['weight_max']);
        
        $packageWeight = ceil($weig * $paper_amount/ 1000 / $packageCount);
        
        $this->packingCostForPaper['packageCount'] = $packageCount;
        $this->packingCostForPaper['packageWeight'] = $packageWeight;

        return $this->packingCostForPaper;
    }

}
