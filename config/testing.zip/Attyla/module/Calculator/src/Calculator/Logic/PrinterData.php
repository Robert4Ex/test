<?php

/*
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 * 
 * Data zmian 04-03-2016
 */

namespace Calculator\Logic;

class PrinterData {

    public function matrixCost($sql, $id_printer, $print_type) {

        $select = $sql->select();
        $select->from(array('MF' => 'material_features'));
        $select->columns(array('value'));
        $select->join(array('MM' => 'material'), 'MF.id_material = MM.id', array(), 'right');
        $select->where(array('"MF"."id_feature" = 9', 'MM.id' => $id_printer));

        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        $printerData = array();

        
        
        foreach ($result as $res) {

            $printerData['matrixData'] = (int) $res['value'];
        }

        $select = $sql->select();
        $select->from(array('MF' => 'material_features'));
        $select->join(array('MF2' => 'material_features'), 'MF.id_feature_base = MF2.id_feature_base', array('val' => 'value'), 'left');
        $select->where(array('"MF2"."id_feature" in (7,8)', 'MF.id_material' => $id_printer));

        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        
        foreach ($result as $res) {

            $printerData[] = (int) $res['val'];
            $printerData['id_printer_size'] = (int) $res['id_feature_base'];
        }

        $matrix = $this->amountMatrix($sql, $print_type);
        $printerData['matrix'] = $matrix['matrix'];
        
        return $printerData;
    }

    public function amountMatrix($sql, $print_type) {

        $select = $sql->select();
        $select->from(array('MF' => 'material_features'));
        $select->columns(array('value'));
        $select->join(array('MF2' => 'material_features'), 'MF.id_feature_base = MF2.id', array(), 'left');
        $select->where(array('"MF2"."id" != "MF"."id"', 'MF2.id_feature_base' => $print_type));

        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        $amountMatrix = array();
        
        foreach ($result as $res) {

            $amountMatrix['matrix'] = (int) $res['value'];
        }
        
        return $amountMatrix;
        
    }

    
    public function matrixCostPrimo($sql, $id_printer, $print_type, $id) {
        
        $select = $sql->select();
        $select->from(array('MF' => 'material_features'));
        $select->columns(array('value'));
        $select->join(array('MM' => 'material'), 'MF.id_material = MM.id', array(), 'right');
        $select->where(array('"MF"."id_feature" = 9', 'MM.id' => $id_printer));

        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();
        
        $printerData = array(); 

        foreach ($result as $res) {

            $printerData['matrixData'] = (int) $res['value'];
        }

        $select = $sql->select();
        $select->from(array('MF' => 'material_features'));
        $select->where(array('"MF"."id_feature" in (7,8)', 'MF.id_feature_base' => $id));

        
        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        foreach ($result as $res) {

            $printerData[] = (int) $res['value'];
            $printerData['id_printer_size'] = (int) $id_printer;
        }
        
        
        
        $matrix = $this->amountMatrix($sql, $print_type);
        $printerData['matrix'] = $matrix['matrix'];

        return $printerData;
    }
    
    
    public function printerName($sql, $id_printer) {
        
        $select = $sql->select();
        $select->from(array('material'=>'material'));
        $select->columns(array('name'));
        $select->where(array('id' => $id_printer, 'id_material_class' => 2));

        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();      
        
        $printer = array();
        
        foreach ($result as $res){
            $printer['name'] = $res['name'];
        }
        
        return $printer;
        
    }
    
    public function printTypeName($sql, $print_type) {
        
        $select = $sql->select();
        $select->from(array('MF'=>'material_features'));
        $select->columns(array('value'));
        $select->where(array('id' => $print_type, 'id_material_class' => 1));

        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();      
        
        $printTypeName = array();
        
        foreach ($result as $res){
            $printTypeName['printTypeName'] = $res['value'];
        }
        
        return $printTypeName;
        
    }
 
        public function getAllPrinter($sql) {
        
        $select = $sql->select();
        $select->from(array('material'=>'material'));
        $select->columns(array('name', 'id'));
        $select->where(array('id_material_class' => 2));

        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();     
        
        $allPrinter = array();
        
        $i = 0;
        
        foreach ($result as $res){
            
            $allPrinter[$i]['id'] = $res['id'];
            $allPrinter[$i]['name'] = $res['name'];
            
            $i++;
        }
        
        return $allPrinter;
    }
    
        
    
}
