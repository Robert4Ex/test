<?php

/*
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 * 
 * Data zmian: 04-03-2016
 * 
 */

namespace Calculator\Logic;

class Dimensions {

    public $dimensionData = array();
    public $dimensionPrinterData = array();
    public $paperCheck = array();
    
    
    public function paperCheck($heigh, $width, $printerHeigh, $printerWidth) {
        
        
        $poziomoNaArkusz = (floor($printerWidth / $heigh) * floor($printerHeigh / $width));
        $pionowoNaArkusz = (floor($printerHeigh / $heigh) * floor($printerWidth / $width));
        $poleArkusza = ($printerHeigh * $printerWidth);

        if ($poziomoNaArkusz > $pionowoNaArkusz AND $poziomoNaArkusz != 0) {
            $poleNadruku = ($poziomoNaArkusz * $heigh * $width);

            $this->paperCheck['iloscArkuszy'] = $poziomoNaArkusz;
            $this->paperCheck['orientacja'] = 'Poziomo';
            $odpad = round(((($poleArkusza - $poleNadruku) / $poleArkusza) * 100), 2);
            $this->paperCheck['odpad'] = $odpad;
            $this->paperCheck['iloscRzedowPionowo'] = floor($printerWidth/$heigh);
            $this->paperCheck['iloscRzedowPoziomo'] = floor($printerHeigh/$width);            
            
        } else if ($poziomoNaArkusz <= $pionowoNaArkusz AND $pionowoNaArkusz != 0) {
            $poleNadruku = ($pionowoNaArkusz * $heigh * $width);

            $this->paperCheck['iloscArkuszy'] = $pionowoNaArkusz;
            $this->paperCheck['orientacja'] = 'Pionowo';
            $odpad = round(((($poleArkusza - $poleNadruku) / $poleArkusza) * 100), 2);
            $this->paperCheck['odpad'] = $odpad;
            $this->paperCheck['iloscRzedowPionowo'] = floor($printerWidth/$width);
            $this->paperCheck['iloscRzedowPoziomo'] = floor($printerHeigh/$heigh);
            
        } else {
            $this->paperCheck['iloscArkuszy'] = $pionowoNaArkusz;
            $this->paperCheck['orientacja'] = 'Nie mieści się!';
        }
        
        return $this->paperCheck;
    }

    public function getCustomerPaper($sql, $id_size) {

        $select = $sql->select();
        $select->from(array('MF' => 'material_features'));
        $select->columns(array('value'));
        $select->join(array('MF2' => 'material_features'), 'MF.id_feature_base = MF2.id', array(), 'left');
        $select->where(array('"MF2"."id" != "MF"."id"', 'MF2.id_feature_base' => $id_size));

        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        foreach ($result as $res) {

            $this->dimensionData[] = (int) $res['value'];
        }
        
        return $this->dimensionData;
    }

    public function getPrinterPaper($sql, $id_printer) {

        $select = $sql->select();
        $select->from(array('MF' => 'material_features'));
        $select->columns(array('id_feature_base'));
        $select->join(array('MF2' => 'material_features'), 'MF.id_feature_base = MF2.id', array(), 'left');
        $select->where(array('"MF2"."id" != "MF"."id"', 'MF.id_material' => $id_printer));

        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();

        foreach ($result as $res) {

            $this->dimensionPrinterData['id_printer_paper'] = (int) $res['id_feature_base'];
        }        
        
        return $this->dimensionPrinterData;
    }

}
