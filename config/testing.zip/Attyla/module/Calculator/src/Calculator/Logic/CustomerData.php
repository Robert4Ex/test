<?php

/* 
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 * 
 * Data zmian: 04-03-2016
 */

namespace Calculator\Logic;

class CustomerData {
    
    public $customer = array();


    public function getCustomer($sql, $id_customer) {
        
        $select = $sql->select();
        $select->from(array('customers'=>'customers'));
        $select->columns(array('name', 'surname'));
        $select->where(array('id' => $id_customer));

        $statement = $sql->prepareStatementForSqlObject($select);
        $result = $statement->execute();      
        
        foreach ($result as $res){
            $this->customer['name'] = $res['name'];
            $this->customer['surname'] = $res['surname'];
        }

        return $this->customer;
        
    }
    
}