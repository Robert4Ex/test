<?php

/*
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 * 
 * Data zmian: 04-03-2016
 * 
 */

namespace Calculator\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Calculator\Model\CalculatePoster;
use Calculator\Form\CalculatePosterForm;
use Zend\View\Model\ViewModel;

class CalculateController extends AbstractActionController {

    protected $CalculatePosterTable;
    protected $CustomerTable;

    public function indexAction() {

        return array(
            'calculator' => $this->getCalculatePosterTable()->fetchAll(),
        );
    }

    public function editAction() {

        $id = (int) $this->params()->fromRoute('id', 0);

        $a = $this->getCalculatePosterTable()->getOnePosterCalculate($id);

        $dbAdapter = $this->getServiceLocator()->get('Zend\Db\Adapter\Adapter');



        $form = new CalculatePosterForm($dbAdapter);
        $form->bind($a);
        $form->get('submit')->setValue('Edytuj');
        $request = $this->getRequest();

        if ($request->isPost()) {
            //$form->setInputFilter($a->getInputFilter());
            $form->setData($request->getPost());

            if ($form->isValid()) {
                $selectCalculate = $this->getCalculatePosterTable()->selectCalculate($a);

                $dataSelect = array('calculate' => $selectCalculate);

                $view = new ViewModel($dataSelect);
                $view->setTemplate('calculator/calculate/select-calculate');

                return $view;

                //return $this->redirect()->toRoute('select-calculate');
            }
        }

        return array(
            'id' => $id,
            'form' => $form,
        );
    }

    public function addOneAction() {

        $id = $this->params()->fromRoute('id', 0);

        $this->getCalculatePosterTable()->addOne($id);

        return $this->redirect()->toRoute('calculate-poster');
    }

    public function addAction() {

        $dbAdapter = $this->getServiceLocator()->get('Zend\Db\Adapter\Adapter');

        $form = new CalculatePosterForm($dbAdapter);

        $form->get('submit')->setValue('Wylicz');

        $request = $this->getRequest();

        if ($request->isPost()) {

            $a = new CalculatePoster();

            $form->setData($request->getPost());

            if ($form->isValid()) {

                $a->exchangeArray($form->getData());

                $selectCalculate = $this->getCalculatePosterTable()->selectCalculate($a);

                $dataSelect = array('calculate' => $selectCalculate);

                $this->getCalculatePosterTable()->save($dataSelect['calculate']);

                $view = new ViewModel($dataSelect);
                $view->setTemplate('calculator/calculate/select-calculate');

                return $view;
            }
        }
        return array('form' => $form);
    }

    public function deleteAction() {
        $id = (int) $this->params()->fromRoute('id', 0);

        $this->getCalculatePosterTable()->delete($id);
        return $this->redirect()->toRoute('calculate-poster');
    }

    public function deleteAllAction() {
        $this->getCalculatePosterTable()->deleteAll();
        return $this->redirect()->toRoute('calculate-poster');
    }

    public function getCalculatePosterTable() {
        if (!$this->CalculatePosterTable) {
            $sm = $this->getServiceLocator();
            $this->CalculatePosterTable = $sm->get('Calculator\Model\CalculatePosterTable');
        }

        return $this->CalculatePosterTable;
    }

}
