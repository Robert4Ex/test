<?php

/*
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 */

namespace Calculator\Controller;

use Zend\Mvc\Controller\AbstractActionController;

class PriceSettingsController extends AbstractActionController {

    protected $PriceSettingsTable;

    public function indexAction() {

        return array(
            'paperPrice' => $this->getPriceSettingsTable()->getAllPaperPrice(),
            'matrixPrice' => $this->getPriceSettingsTable()->getAllMatrixPrice(),
            'courierPrice' => $this->getPriceSettingsTable()->getAllCourierPrice(),
        );
    }

    public function editMatrixPrice($id) {
        
        return;
        
    }
    
    public function deleteMatrixPrice($id) {
        
        return;
        
    }
    
    
    public function getPriceSettingsTable() {
        if (!$this->PriceSettingsTable) {
            $sm = $this->getServiceLocator();
            $this->PriceSettingsTable = $sm->get('Calculator\Model\PriceSettingsTable');
        }

        return $this->PriceSettingsTable;
    }

}
