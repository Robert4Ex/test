<?php

/*
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 * 
 * Data zmian: 04-09-2015
 * 
 */

namespace Calculator\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Calculator\Model\Range;
use Calculator\Form\RangeForm;
use Calculator\Model\Foliation;
use Calculator\Form\FoliationForm;

class RangeController extends AbstractActionController {

    public function indexAction() {

        return array(
            'calculator' => $this->getCalculatorTable()->select(),
            'foliation' => $this->getFoliationTable()->select(),
            'cutting' => $this->getCuttingTable()->select(),
        );
    }

    public function addPaperAction() {

        $dbAdapter = $this->getServiceLocator()->get('Zend\Db\Adapter\Adapter');

        $form = new RangeForm($dbAdapter);
        $form->get('submit')->setValue('Dodaj');
        $request = $this->getRequest();

        if ($request->isPost()) {

            $a = new Range();
            // $form->setInputFilter($a->getInputFilter());
            $form->setData($request->getPost());
            if ($form->isValid()) {

                $a->exchangeArray($form->getData());

                $this->getCalculatorTable()->save($a);
                return $this->redirect()->toRoute('range');
            }
        }

        return array('form' => $form);
    }

    public function deletePaperAction() {
        $id = (int) $this->params()->fromRoute('id', 0);

        // $this->getCalculatorTable()->remove($id);
        return $this->redirect()->toRoute('range');
    }

    public function editPaperAction() {

        $dbAdapter = $this->getServiceLocator()->get('Zend\Db\Adapter\Adapter');

        $id = (int) $this->params()->fromRoute('id', 0);
        $a = $this->getCalculatorTable()->get($id);
        $form = new RangeForm($dbAdapter);
        $form->bind($a);
        $form->get('submit')->setAttribute('value', 'Edytuj');
        $request = $this->getRequest();

        if ($request->isPost()) {
            //$form->setInputFilter($a->getInputFilter());
            $form->setData($request->getPost());

            if ($form->isValid()) {

                $this->getCalculatorTable()->save($a);
                return $this->redirect()->toRoute('range');
            }
        }

        return array(
            'id' => $id,
            'form' => $form,
        );
    }

    public function addFoliationAction() {

        $dbAdapter = $this->getServiceLocator()->get('Zend\Db\Adapter\Adapter');

        $form = new FoliationForm($dbAdapter);
        $form->get('submit')->setValue('Dodaj');
        $request = $this->getRequest();

        if ($request->isPost()) {

            $a = new Foliation();
            // $form->setInputFilter($a->getInputFilter());
            $form->setData($request->getPost());
            if ($form->isValid()) {

                $a->exchangeArray($form->getData());

                $this->getFoliationTable()->save($a);
                return $this->redirect()->toRoute('range');
            }
        }

        return array('form' => $form);
    }

    public function deleteFoliationAction() {
        $id = (int) $this->params()->fromRoute('id', 0);

        //  $this->getFoliationTable()->remove($id);
        return $this->redirect()->toRoute('range');
    }

    public function editFoliationAction() {

        $dbAdapter = $this->getServiceLocator()->get('Zend\Db\Adapter\Adapter');

        $id = (int) $this->params()->fromRoute('id', 0);
        $a = $this->getFoliationTable()->get($id);
        $form = new FoliationForm($dbAdapter);
        $form->bind($a);
        $form->get('submit')->setAttribute('value', 'Edytuj');
        $request = $this->getRequest();
        if ($request->isPost()) {
            //$form->setInputFilter($a->getInputFilter());
            $form->setData($request->getPost());

            if ($form->isValid()) {
                $this->getFoliationTable()->save($a);
                return $this->redirect()->toRoute('range');
            }
        }

        return array(
            'id' => $id,
            'form' => $form,
        );
    }

    protected $CalculatorTable;
    protected $FoliationTable;
    protected $CuttingTable;
    protected $CustomerTable;

    public function getCalculatorTable() {
        if (!$this->CalculatorTable) {
            $sm = $this->getServiceLocator();
            $this->CalculatorTable = $sm->get('Calculator\Model\RangeTable');
        }

        return $this->CalculatorTable;
    }

    public function getFoliationTable() {
        if (!$this->FoliationTable) {
            $sm = $this->getServiceLocator();
            $this->FoliationTable = $sm->get('Calculator\Model\FoliationTable');
        }

        return $this->FoliationTable;
    }

    public function getCuttingTable() {
        if (!$this->CuttingTable) {
            $sm = $this->getServiceLocator();
            $this->CuttingTable = $sm->get('Calculator\Model\CuttingTable');
        }
 
        return $this->CuttingTable;
    }

}
