<?php

/*
 * @author Robert Kawalec <r.kawalec@vp.pl>
 * @version: 1.0
 */

namespace Calculator\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Calculator\Model\Customer;
use Calculator\Form\CustomerForm;

class CustomerController extends AbstractActionController {

    protected $Table;

    public function indexAction() {

        return array(
            'customer' => $this->getTable()->fetchAll(),
        );
    }

    public function deleteAction() {
        $request = $this->getRequest();
        $id = (int) $this->params()->fromRoute('id', 0);

        $this->getTable()->delete($id);
        return $this->redirect()->toRoute('customer');
    }

    public function getTable() {
        if (!$this->Table) {
            $sm = $this->getServiceLocator();
            $this->Table = $sm->get('Calculator\Model\CustomerTable');
        }

        return $this->Table;
    }

    public function editAction() {

        $id = (int) $this->params()->fromRoute('id', 0);

        $a = $this->getTable()->getOne($id);

        $form = new CustomerForm();
        $form->bind($a);
        $form->get('submit')->setAttribute('value', 'Edytuj');
        $request = $this->getRequest();

        if ($request->isPost()) {
            //$form->setInputFilter($a->getInputFilter());
            $form->setData($request->getPost());
            if ($form->isValid()) {
                $this->getTable()->save($a);
                return $this->redirect()->toRoute('customer');
            }
        }

        return array(
            'id' => $id,
            'form' => $form,
        );
    }

    public function addAction() {

        $form = new CustomerForm();
        $form->get('submit')->setValue('Dodaj');
        $request = $this->getRequest();


        if ($request->isPost()) {

            $a = new Customer();

            $form->setData($request->getPost());
            if ($form->isValid()) {

                $a->exchangeArray($form->getData());

                $this->getTable()->save($a);
                return $this->redirect()->toRoute('customer');
            }
        }
        return array('form' => $form);
    }

}
