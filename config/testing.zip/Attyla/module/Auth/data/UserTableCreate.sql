CREATE TABLE public.users_new (
  id SERIAL,
  first_name VARCHAR(45) NOT NULL,
  surname VARCHAR(45) NOT NULL,
  username TEXT,
  email VARCHAR(101) NOT NULL,
  password VARCHAR(45) NOT NULL,
  password_salt TEXT,
  registration_date TIMESTAMP(0) WITHOUT TIME ZONE,
  email_confirmed TEXT,
  active INTEGER DEFAULT 1 NOT NULL,
  CONSTRAINT users_new_pkey PRIMARY KEY(id)
) 
WITH (oids = false);
