<?php

namespace Auth;

// Add this for Table Date Gateway
use Auth\Model\Auth;
use Auth\Model\Role;
use Auth\Model\UsersTable;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Authentication\Adapter\DbTable as DbTableAuthAdapter;
use Zend\Mvc\MvcEvent;
use Zend\Authentication\AuthenticationService;
// Add this for SMTP transport
use Zend\ServiceManager\ServiceManager;
use Zend\Mail\Transport\Smtp;
use Zend\Mail\Transport\SmtpOptions;
use Zend\Mvc\Router\RouteMatch;

class Module {
    
    private $userTable = 'users_new';

    public function getConfig() {
        return include __DIR__ . '/config/module.config.php';
    }

    public function getAutoloaderConfig() {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }

    public function getServiceConfig() {

        return array(
            'factories' => array(
                // For Yable data Gateway
                'Auth\Model\UsersTable' => function($sm) {
                    $tableGateway = $sm->get('UsersTableGateway');
                    $table = new UsersTable($tableGateway);
                    return $table;
                },
                'UsersTableGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Auth()); // Notice what is set here
                    return new TableGateway($this->userTable, $dbAdapter, null, $resultSetPrototype);
                },
                'Auth\Model\AuthStorage' => function ($serviceManager) {
                    return new \Auth\Model\AuthStorage('authStorage');
                },
                'Auth\Logic\Auth' => function (ServiceManager $serviceManager) {
                    $config = $serviceManager->get('Config');
                    return $config;
                },
                'Auth\Service\UserMailServices' => function ($serviceManager) {
                    return new \Auth\Service\UserMailServices($serviceManager);
                },
                'AuthService' => function ($serviceManager) {
                    $dbAdapter = $serviceManager->get('Zend\Db\Adapter\Adapter');
                    $dbTableAuthAdapter = new DbTableAuthAdapter($dbAdapter, $this->userTable, 'name', 'password');

                    $authService = new AuthenticationService();
                    $authService->setAdapter($dbTableAuthAdapter);
                    $authService->setStorage($serviceManager->get('Auth\Model\AuthStorage'));

                    return $authService;
                },
                'Auth\Model\RoleTable' =>  function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table = new Model\RoleTable($dbAdapter);
                    return $table;
                },
                
            ),
        );
    }

    public function onBootstrap($e) {
        $app = $e->getApplication();
        $em = $app->getEventManager();
        $sm = $app->getServiceManager();
        $config = $sm->get('Config');
//        var_dump($config['whitelist']);
        $list = $config['whitelist'];
        $auth = $sm->get('AuthService');
//                    var_dump($em);
        $em->attach(MvcEvent::EVENT_ROUTE, function ($e) use($list, $auth, $sm) {
            $match = $e->getRouteMatch();
            // No route match, this is a 404
            if (!$match instanceof RouteMatch) {
                return;
            }
            // Route is whitelisted
            $name = $sm->get('request')
                    ->getUri()
                    ->getPath();
//        var_dump($name);
            if (strpos($name, 'forgotten-password') || in_array($name, $list)) {
                return;
            }
//                    var_dump($name);
            // User is authenticated
            if ($auth->hasIdentity()) {
                return;
            }

            // Redirect to the user login page, as an example
            $router = $e->getRouter();
            $url = $router->assemble(array(), array(
                'name' => 'auth'
            ));

            $response = $e->getResponse();
            $response->getHeaders()
                    ->addHeaderLine('Location', $url);
            $response->setStatusCode(302);

            return $response;
        }, - 100);
    }

}
