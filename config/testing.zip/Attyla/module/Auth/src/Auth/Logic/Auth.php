<?php

namespace Auth\Logic;

class Auth extends AbstractAuth {

    protected $config;
    protected $usersTable;

    public function __construct($config = null) {
        $this->config = (isset($config) ? $config : null);
        return $this;
    }

    public function prepareData($data) {
        $data['password_salt'] = $this->generateDynamicSalt();
        $data['password'] = $this->encriptPassword(
                $this->getStaticSalt(), $data['password'], $data['password_salt']
        );
        $data['registration_date'] = date('Y-m-d H:i:s');	
        $data['email_confirmed'] = 0;
        return $data;
    }

    public function generateDynamicSalt() {
        $dynamicSalt = '';
        for ($i = 0; $i < 50; $i++) {
            $dynamicSalt .= chr(rand(33, 126));
        }
        return $dynamicSalt;
    }

    public function getStaticSalt() {
        $staticSalt = '';
        $config = $this->getServiceLocator()->get('config');
        $staticSalt = $config['static_salt'];
        return $staticSalt;
    }

    public function encriptPassword($staticSalt, $password, $dynamicSalt) {
        return $password = md5($staticSalt . $password . $dynamicSalt);
    }

    public function getUsersTable() {
        if (!$this->usersTable) {
            $this->usersTable = $this->service_manager->get('Auth\Model\UsersTable');
        }
        return $this->usersTable;
    }

    public function sendConfirmationEmail($auth) {
        // $view = $this->getServiceLocator()->get('View');
        $UserMailServices = $this->getServiceLocator()->get('Auth\Service\UserMailServices');
        $this->getRequest()->getServer();  //Server vars
        $config = $this->getServiceLocator()->get('config');
        $body = "Please, click the link to confirm your registration => " .
                $this->getRequest()->getServer('HTTP_ORIGIN') .
                $this->url()->fromRoute('auth/default', array(
                    'controller' => 'registration',
                    'action' => 'confirm-email',
                    'id' => $auth->registration_token));

        $mailData['mailTo'] = $auth->email;
        $mailData['mailFrom'] = $config['settings']['EMAIL']['FROM'];
        $mailData['mailFromNickName'] = $config['settings']['EMAIL']['MAIL_FROM_NICK_NAME'];
        $mailData['mailSubject'] = $config['settings']['REGISTRATION_MAIL_SUBJECT'];
        $mailData['mailBody'] = $body;
        $UserMailServices->sendMail($mailData);
    }

    public function sendPasswordByEmail($email, $password) {

        $UserMailServices = $this->getServiceLocator()->get('Auth\Service\UserMailServices');
        $request = new \Zend\Http\PhpEnvironment\Request();
        $config = $this->getServiceLocator()->get('config');
//        vd(__DIR__ . '/../../../view/auth/index/templates/recovery_password.phtml');
        $view = new \Zend\View\Renderer\PhpRenderer();
        $resolver = new \Zend\View\Resolver\TemplateMapResolver();
        $resolver->setMap(array(
            'mailTemplate' => __DIR__ . '/../../../view/auth/index/templates/recovery_password.phtml'
        ));
        $view->setResolver($resolver);
        $viewModel = new \Zend\View\Model\ViewModel();
        $viewModel->setTemplate('mailTemplate');
        $bodyMessage = new \Zend\Mime\Part($view->render($viewModel));
//        vd($bodyPart);
        $mailData['mailTo'] = $email;
        $mailData['mailFrom'] = $config['settings']['EMAIL']['FROM'];
        $mailData['mailFromNickName'] = $config['settings']['EMAIL']['MAIL_FROM_NICK_NAME'];
        $mailData['mailSubject'] = 'Your password has been changed!';
        $mailData['mailBody'] = $password;
        $UserMailServices->sendMail($mailData);
    }

    public function generatePassword($l = 8, $c = 0, $n = 0, $s = 0) {
        // get count of all required minimum special chars
        $count = $c + $n + $s;
        $out = '';
        // sanitize inputs; should be self-explanatory
        if (!is_int($l) || !is_int($c) || !is_int($n) || !is_int($s)) {
            trigger_error('Argument(s) not an integer', E_USER_WARNING);
            return false;
        } elseif ($l < 0 || $l > 20 || $c < 0 || $n < 0 || $s < 0) {
            trigger_error('Argument(s) out of range', E_USER_WARNING);
            return false;
        } elseif ($c > $l) {
            trigger_error('Number of password capitals required exceeds password length', E_USER_WARNING);
            return false;
        } elseif ($n > $l) {
            trigger_error('Number of password numerals exceeds password length', E_USER_WARNING);
            return false;
        } elseif ($s > $l) {
            trigger_error('Number of password capitals exceeds password length', E_USER_WARNING);
            return false;
        } elseif ($count > $l) {
            trigger_error('Number of password special characters exceeds specified password length', E_USER_WARNING);
            return false;
        }

        // all inputs clean, proceed to build password
        // change these strings if you want to include or exclude possible password characters
        $chars = "abcdefghijklmnopqrstuvwxyz";
        $caps = strtoupper($chars);
        $nums = "0123456789";
        $syms = "!@#$%^&*()-+?";

        // build the base password of all lower-case letters
        for ($i = 0; $i < $l; $i++) {
            $out .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
        }

        // create arrays if special character(s) required
        if ($count) {
            // split base password to array; create special chars array
            $tmp1 = str_split($out);
            $tmp2 = array();

            // add required special character(s) to second array
            for ($i = 0; $i < $c; $i++) {
                array_push($tmp2, substr($caps, mt_rand(0, strlen($caps) - 1), 1));
            }
            for ($i = 0; $i < $n; $i++) {
                array_push($tmp2, substr($nums, mt_rand(0, strlen($nums) - 1), 1));
            }
            for ($i = 0; $i < $s; $i++) {
                array_push($tmp2, substr($syms, mt_rand(0, strlen($syms) - 1), 1));
            }

            // hack off a chunk of the base password array that's as big as the special chars array
            $tmp1 = array_slice($tmp1, 0, $l - $count);
            // merge special character(s) array with base password array
            $tmp1 = array_merge($tmp1, $tmp2);
            // mix the characters up
            shuffle($tmp1);
            // convert to string for output
            $out = implode('', $tmp1);
        }

        return $out;
    }

}
