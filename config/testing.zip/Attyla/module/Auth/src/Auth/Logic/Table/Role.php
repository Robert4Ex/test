<?php
/**
 * ZfTable ( Module for Zend Framework 2)
 *
 */

namespace Auth\Logic\Table;

use ZfTable\AbstractTable;

class Role extends AbstractTable
{

    protected $config = array(
        'name' => 'Role',
        'showPagination' => true,
        'showQuickSearch' => false,
        'showItemPerPage' => true,
        'itemCountPerPage' => 10,
        'showColumnFilters' => false,
        'showExportToCSV' => true,
        'valuesOfItemPerPage' => array(1, 5 , 10, 20, 50 , 100 , 200),
        'rowAction' => ''
    );

    /**
     * @var array Definition of headers
     */
    protected $headers = array(
        'id' => array('title' => 'Id', 'width' => 50) ,
        'role_name' => array('title' => 'Name', 'filters' => 'text'),
        'status' => array('title' => 'Status' , 'width' => 100  , 'filters' => array( null => 'All' , 'Active' => 'Active' , 'Inactive' => 'Inactive')),
        '_actions' => array('title' => 'Actions' , 'width' => 150),
    );

    public function init()
    {
        $this->setActions(  
                array(
                 array( 
                        'controller' => 'event',
                        'action' => 'ajax-confirm-generic',
                        'params' => array('id' => 'id'),
                        'class' => 'ico_event ico_confirm',
                        'id' => 'event_confirm',
                        'title' => 'Confirm',
                        'label' => 'Confirm',
                        'popup' => true,
                    ),
                ));
        
        $this->getHeader('_actions')->setWidth('200px');
    }

    protected function initFilters($query)
    {
        if ($value = $this->getParamAdapter()->getValueOfFilter('role_name')) {
            $query->where("role_name like '%".$value."%' ");
        }
        if ($value = $this->getParamAdapter()->getValueOfFilter('active')) {
            $query->where("status = '".$value."' ");
        }
    }
}
