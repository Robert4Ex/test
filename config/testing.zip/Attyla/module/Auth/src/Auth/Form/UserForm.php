<?php

namespace Auth\Form;

use Zend\Form\Form;
use Auth\Logic\Auth;

class UserForm extends Form {

    public function __construct($name = null) {
        parent::__construct('registration');
        $this->setAttribute('method', 'post');

        $this->add(array(
            'name' => 'first_name',
            'attributes' => array(
                'type' => 'text',
            ),
            'options' => array(
                'label' => 'Imię',
            ),
        ));
        
        $this->add(array(
            'name' => 'surname',
            'attributes' => array(
                'type' => 'text',
            ),
            'options' => array(
                'label' => 'Nazwisko',
            ),
        ));
        
        $this->add(array(
            'name' => 'username',
            'attributes' => array(
                'type' => 'text'
            ),
            'options' => array(
                'label' => 'Nazwa użytkownika',
            ),
        ));
        
        $this->add(array(
            'name' => 'password',
            'attributes' => array(
                'type' => 'password',
            ),
            'options' => array(
                'label' => 'Hasło',
            ),
        ));

        $this->add(array(
            'name' => 'email',
            'attributes' => array(
                'type' => 'email',
            ),
            'options' => array(
                'label' => 'E-mail',
            ),
        ));
        $this->add(array(
            'name' => 'active',
            'type' => 'Zend\Form\Element\Select',
            'options' => array(
                'label' => 'Aktywne',
                'value_options' => array(
                    '0' => 'Nie',
                    '1' => 'Tak',
                ),
            ),
        ));
        
        $this->add(array(
            'name' => 'submit',
            'attributes' => array(
                'type' => 'submit',
                'value' => 'Zapisz',
                'id' => 'submitbutton',
            ),
        ));
    }

}
