<?php
namespace Auth\Form;

use Zend\Form\Form;

class AuthForm extends Form
{
    public function __construct($name = null)
    {
        parent::__construct('auth');
        $this->setAttribute('method', 'post');

        $this->add(array(
            'name' => 'username',
            'attributes' => array(
                'placeholder' => 'Nazwa użytkownika',
                'id' => 'username',
                'required' => true,
                'title' => 'Wpisz nazwę użytkownika',
                'data-toggle' => 'tooltip'
            ),
            'options' => array(
                'label' => 'Nazwa użytkownika',
               
            )
        ));
        $this->add(array(
            'name' => 'password',
            'options' => array(
                'label' => 'Hasło'
            ),
            'attributes' => array(
                'placeholder' => 'Hasło',
                'id' => 'password',
                'type' => 'password',
                'required' => true,
                'title' => 'Wpisz hasło',
                'data-toggle' => 'tooltip'
            ),
        ));
        $this->add(array(
            'name' => 'rememberme',
            'type' => 'checkbox',
            'options' => array(
                'label' => 'Zapamiętaj',
                'checked_value' => 'true',
                'unchecked_value' => 'false',
                'label_attributes' => array('class' => 'col-sm-2')
            ),
        ));	
        $this->add(array(
            'name' => 'submit',
            'attributes' => array(
                'type'  => 'submit',
                'value' => 'Go',
                'id' => 'submitbutton',
                'class'=>'btn btn-primary btn-block'
            ),
        )); 
    }
}