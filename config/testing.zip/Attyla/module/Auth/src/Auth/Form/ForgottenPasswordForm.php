<?php
namespace Auth\Form;

use Zend\Form\Form;

class ForgottenPasswordForm extends Form
{
    const EMAIL_PASSWORD_SEND_MESSAGE = 'Hasło zostało wysłane na email: ';
    const EMAIL_NOT_VALID = 'Podany e-mail jest nieprawidłowy';
    
    
    public function __construct($name = null)
    {
        parent::__construct('registration');
        $this->setAttribute('method', 'post');
		
        $this->add(array(
            'name' => 'username',
            'attributes' => array(
                'placeholder' => 'Nazwa użytkownika',
                'type' => 'username',
                'required' => true,
                'title' => 'Wpisz nazwę użytkownika',
                'data-toggle' => 'tooltip'
            ),
        ));	
		
        $this->add(array(
            'name' => 'submit',
            'attributes' => array(
                'type'  => 'submit',
                'value' => 'Remind password',
                'id' => 'submitbutton',
                'class'=>'btn btn-primary btn-block'
            ),
        )); 
    }
}