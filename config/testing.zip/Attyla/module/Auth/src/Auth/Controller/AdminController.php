<?php

namespace Auth\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Db\TableGateway\TableGateway;
use Auth\Form\UserForm;
use Auth\Form\UserFilter;
use Auth\Logic;

class AdminController extends AbstractActionController {

    protected $usersTable = null;
    
    // R - retrieve = Index
    public function indexAction() {
        return new ViewModel(array('rowset' => $this->getUsersTable()->select()));
    }

    // C - Create
    public function createAction() {
        $form = new UserForm($this->getServiceLocator());
        $request = $this->getRequest();
        if ($request->isPost()) {
            $form->setInputFilter(new UserFilter($this->getServiceLocator()));
            $form->setData($request->getPost());
            if ($form->isValid()) {
                $config = $this->getServiceLocator()->get('Config');
              
                $AuthLogic = new \Auth\Logic\Auth($config);
                $data = $form->getData();

                $data['password_salt'] = $AuthLogic->generateDynamicSalt();
                $data['password'] = $AuthLogic->encriptPassword(
                        $AuthLogic->getStaticSalt(), $data['password'], $data['password_salt']
                );              
                
                unset($data['submit']);
                if (empty($data['registration_date']))
                    $data['registration_date'] = date('Y-m-d H:i:s');
                $this->getUsersTable()->insert($data);
                return $this->redirect()->toRoute('auth/default', array('controller' => 'admin', 'action' => 'index'));
            }
        }
        return new ViewModel(array('form' => $form));
    }
    // U - Update
    public function updateAction() {
        $id = $this->params()->fromRoute('id');
        if (!$id)
            return $this->redirect()->toRoute('auth/default', array('controller' => 'admin', 'action' => 'index'));
        $form = new UserForm();
        $request = $this->getRequest();
        if ($request->isPost()) {
            $userFilter = new UserFilter($this->getServiceLocator());
            $userFilter->remove('username');
            $form->setInputFilter($userFilter);
            $form->setData($request->getPost());
            if ($form->isValid()) {
                $data = $form->getData();
                $sm = $this->getServiceLocator();
                $zl = new Logic\Auth();
                $zl->setServiceLocator($sm);

                    
                $data['password_salt'] = $zl->generateDynamicSalt();
                $data['password'] = $zl->encriptPassword(
                        $zl->getStaticSalt(), $data['password'], $data['password_salt']
                );              
                unset($data['submit']);
                if (empty($data['registration_date']))
                    $data['registration_date'] = date('Y-m-d H:i:s');
                $this->getUsersTable()->update($data, array('id' => $id));
                return $this->redirect()->toRoute('auth/default', array('controller' => 'admin', 'action' => 'index'));
            }
        }
        else {
            $form->setData($this->getUsersTable()->select(array('id' => $id))->current());
        }

        return new ViewModel(array('form' => $form, 'id' => $id));
    }

    // D - delete
    public function deleteAction() {
        $id = $this->params()->fromRoute('id');
        if ($id) {
            $this->getUsersTable()->delete(array('id' => $id));
        }

        return $this->redirect()->toRoute('auth/default', array('controller' => 'admin', 'action' => 'index'));
    }

    public function getUsersTable() {
        // I have a Table data Gateway ready to go right out of the box
        if (!$this->usersTable) {
            $this->usersTable = new TableGateway(
                    'users_new', $this->getServiceLocator()->get('Zend\Db\Adapter\Adapter')
//				new \Zend\Db\TableGateway\Feature\RowGatewayFeature('id') // Zend\Db\RowGateway\RowGateway Object
//				ResultSetPrototype
            );
        }
        return $this->usersTable;
    }
}
