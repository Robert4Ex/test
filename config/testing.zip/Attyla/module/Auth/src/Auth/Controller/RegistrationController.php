<?php

namespace Auth\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Auth\Model\Auth;
use Auth\Form\RegistrationForm;
use Auth\Form\RegistrationFilter;
use Auth\Form\ForgottenPasswordForm;
use Auth\Form\ForgottenPasswordFilter;
// a test class in a coolcsn namespace for installer. You can remove the next line
use CsnBase\Zend\Validator\ConfirmPassword;
use Zend\Mail\Message;

class RegistrationController extends AbstractActionController {

    protected $usersTable;

    public function indexAction() {
        // A test instantiation to make sure it works. Not used in the application. You can remove the next line
        // $myValidator = new ConfirmPassword();
        $form = new RegistrationForm();
        $form->get('submit')->setValue('Register');

        $request = $this->getRequest();
        if ($request->isPost()) {

            $form->setInputFilter(new RegistrationFilter($this->getServiceLocator()));
            $form->setData($request->getPost());
            
            if ($form->isValid()) {

                $data = $form->getData();

                $data = $this->prepareData($data);
                $auth = new Auth();
                $auth->exchangeArray($data);

                /* 				
                  // this is replaced by
                  // 1) Manualy composing (wiring) the objects
                  $dbAdapter = $this->getServiceLocator()->get('Zend\Db\Adapter\Adapter');
                  $resultSetPrototype = new \Zend\Db\ResultSet\ResultSet();
                  $resultSetPrototype->setArrayObjectPrototype(new \Auth\Model\Auth());
                  $tableGateway = new \Zend\Db\TableGateway\TableGateway('users', $dbAdapter, null, $resultSetPrototype);
                  $usersTable = new \Auth\Model\UsersTable($tableGateway);
                  // $usersTable->saveUser($auth);
                  // $user7 = $usersTable->getUser(7);

                  $rowset = $tableGateway->select(array('id' => 7));
                  $user7 = $rowset->current();

                  echo '<pre>';
                  var_dump($user7);
                  echo '</pre>';
                 */

                // OR
                // 2) Using the service Locator

                $this->getUsersTable()->saveUser($auth);

                $this->sendConfirmationEmail($auth);
                $this->flashMessenger()->addMessage($auth->email);
                return $this->redirect()->toRoute('auth/default', array('controller' => 'registration', 'action' => 'registration-success'));
            }
        }
        return new ViewModel(array('form' => $form));
    }

    public function registrationSuccessAction() {
        $email = null;
        $flashMessenger = $this->flashMessenger();
        if ($flashMessenger->hasMessages()) {
            foreach ($flashMessenger->getMessages() as $key => $value) {
                $email .= $value;
            }
        }
        return new ViewModel(array('email' => $email));
    }

    public function confirmEmailAction() {
        $token = $this->params()->fromRoute('id');
        $viewModel = new ViewModel(array('token' => $token));
        try {
            $user = $this->getUsersTable()->getUserByToken($token);
            $id = $user->id;
            $this->getUsersTable()->activateUser($id);
        } catch (\Exception $e) {
            $viewModel->setTemplate('auth/registration/confirm-email-error.phtml');
        }
        return $viewModel;
    }

    public function forgottenPasswordAction() {
        $form = new ForgottenPasswordForm();
        $form->get('submit')->setValue('Send');
        $request = $this->getRequest();
        if ($request->isPost()) {
            $form->setInputFilter(new ForgottenPasswordFilter($this->getServiceLocator()));
            $form->setData($request->getPost());
            if ($form->isValid()) {
                $data = $form->getData();
                $email = $data['email'];
                $usersTable = $this->getUsersTable();
                $auth = $usersTable->getUserByEmail($email);
                $password = $this->generatePassword();
                $auth->password = $this->encriptPassword($this->getStaticSalt(), $password, $auth->password_salt);
//				$usersTable->changePassword($auth->id, $password);
// 				or
                $usersTable->saveUser($auth);
                $this->sendPasswordByEmail($email, $password);
                $this->flashMessenger()->addMessage($email);
                return $this->redirect()->toRoute('auth/default', array('controller' => 'registration', 'action' => 'password-change-success'));
            }
        }
        return new ViewModel(array('form' => $form));
    }

    public function passwordChangeSuccessAction() {
        $email = null;
        $flashMessenger = $this->flashMessenger();
        if ($flashMessenger->hasMessages()) {
            foreach ($flashMessenger->getMessages() as $key => $value) {
                $email .= $value;
            }
        }
        return new ViewModel(array('email' => $email));
    }  
}
