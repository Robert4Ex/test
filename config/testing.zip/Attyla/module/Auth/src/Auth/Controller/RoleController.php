<?php

namespace Auth\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Auth\Logic\Table\Role;
use Doctrine\ORM\EntityManager;

class RoleController extends AbstractActionController {

    protected $roleTable;

    public function indexAction() {
        return new ViewModel(array('rowset' => $this->getRoleTable()->fetchAll()));
    }

    public function ajaxBaseAction() {
        
        $sm = $this->getServiceLocator();
        $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
        $table = new Role();
        
        $table->setAdapter($dbAdapter)
                ->setSource($this->getSource())
                ->setParamAdapter($this->getRequest()->getPost())
        ;
        return $this->htmlResponse($table->render());
    }

    public function getRoleTable() {
        if (!$this->roleTable) {
            $sm = $this->getServiceLocator();
            $this->roleTable = $sm->get('Auth\Model\RoleTable');
        }
        return $this->roleTable;
    }
        /**
     *
     * @return \Zend\Db\Sql\Select
     */
    private function getSource()
    {
        return $this->getRoleTable()->fetchAll();
    }
    
    public function htmlResponse($html)
    {
        $response = $this->getResponse();
        $response->setStatusCode(200);
        $response->setContent($html);
        return $response;
    }
}
