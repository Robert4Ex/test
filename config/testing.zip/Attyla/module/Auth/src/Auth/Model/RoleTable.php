<?php

namespace Auth\Model;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Sql;

class RoleTable extends AbstractTableGateway {

    protected $tableGateway;
    public $table = 'role';

    public function __construct(Adapter $adapter) {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new Role());

        $this->initialize();
    }

    public function fetchAll() {
        $sql = new Sql($this->adapter);

        $select = $sql->select();
        $select->from('role')
                ->columns(array('*'))
                ->order('id')
        ;

        return $select;
    }

}
