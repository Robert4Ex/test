<?php

/*
 * @author Artur Łasocha <lasoh1985@gmail.com>
 * @version: 1.0
 */
namespace Auth\Model;

// the object will be hydrated by Zend\Db\TableGateway\TableGateway
class Role {

    public $id;
    public $role_name;
    public $status;

    protected $inputFilter;


    public function exchangeArray($d) {
        $this->id = (!empty($d['id'])) ? $d['id'] : null;
        $this->role_name = (!empty($d['role_name'])) ? $d['role_name'] : null;
        $this->status = (!empty($d['status'])) ? $d['status'] : null;
    }

    public function getArrayCopy() {

        return get_object_vars($this);
    }

}
