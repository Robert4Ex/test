<?php

namespace Auth\Model;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Sql;
use Zend\Db\TableGateway\AbstractTableGateway;

class UsersTable extends AbstractTableGateway {

    protected $tableGateway;
    public $table = 'users_new';

    public function __construct(TableGateway $tableGateway) {
        $this->tableGateway = $tableGateway;
    }

    public function fetchAll() {
        $resultSet = $this->tableGateway->select();
        return $resultSet;
    }

    public function getUser($id) {
        $id = (int) $id;
        $rowset = $this->tableGateway->select(array('id' => $id));
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }

    public function getUserByToken($token) {
        $rowset = $this->tableGateway->select(array('registration_token' => $token));
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $token");
        }
        return $row;
    }

    public function activateUser($id) {
        $data['active'] = 1;
        $data['email_confirmed'] = 1;
        $this->tableGateway->update($data, array('id' => (int) $id));
    }

    public function getUserByEmail($email) {
        $rowset = $this->tableGateway->select(array('email' => $email));
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $email");
        }
        return $row;
    }
    public function getUserByUsername($username) {
        $rowset = $this->tableGateway->select(array('username' => $username));
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $username");
        }
        return $row;
    }

    public function changePassword($id, $password) {
        $data['password'] = $password;
        $this->tableGateway->update($data, array('id' => (int) $id));
    }

    public function saveUser(Auth $auth) {
        // for Zend\Db\TableGateway\TableGateway we need the data in array not object
        $data = array(
            'username'      => $auth->username,
            'password'      => $auth->password,
            'first_name'    => $auth->first_name,
            'surname'       => $auth->surname,
            'email'         => $auth->email,
            'password_salt' => $auth->password_salt,
            'registration_date'     => $auth->registration_date,
//            'registration_token'        => $auth->registration_token,
            'email_confirmed'       => $auth->email_confirmed,
        );
        // If there is a method getArrayCopy() defined in Auth you can simply call it.
        // $data = $auth->getArrayCopy();

        $id = (int) $auth->id;
        if ($id == 0) {
            $this->tableGateway->insert($data);
        } else {
            if ($this->getUser($id)) {
                $this->tableGateway->update($data, array('id' => $id));
            } else {
                throw new \Exception('Form id does not exist');
            }
        }
    }

    public function deleteUser($id) {
        $this->tableGateway->delete(array('id' => $id));
    }

    public function getUserDetailByUsername($username) {
        try {
            $sql = new Sql($this->tableGateway->getAdapter());
            $select = $sql->select()->from(array(
                'sa' => $this->table
            ));
            $select->columns(array(
                'id',
                'email',
                'active',
                'first_name',
                'surname'
            ));
            $select->where(array(
                'username' => $username
            ));

            $roles = $this->tableGateway
                            ->executeSelect($select)->toArray();
            if (!empty($roles[0]) && is_array($roles[0])) {
                return $roles[0];
            }
        } catch (\Exception $e) {
            throw new \Exception($e->getPrevious()->getMessage());
        }
    }

}