<?php

define('REQUEST_MICROTIME', microtime(true));

/**
 * This makes our life easier when dealing with paths. Everything is relative
 * to the application root now.
 */
chdir(dirname(__DIR__));

// Decline static file requests back to the PHP built-in webserver
if (php_sapi_name() === 'cli-server') {
    $path = realpath(__DIR__ . parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
    if (__FILE__ !== $path && is_file($path)) {
        return false;
    }

    unset($path);
}

defined('APPLICATION_PATH')
    || define('APPLICATION_PATH', realpath(dirname(__FILE__) . '/../application'))
;
// Define application environment
defined('APPLICATION_ENV')
    || define('APPLICATION_ENV', (getenv('APP_ENV') ? getenv('APP_ENV') : 'production'))
;

if ('development' === $_SERVER['APP_ENV']) {
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
}
// Setup autoloading
require 'init_autoloader.php';

Zend\Loader\AutoloaderFactory::factory(array(
    'Zend\Loader\StandardAutoloader' => array(
        'namespaces' => array(
            'Logic' => __DIR__ . '/../library/Logic',
            'SqlFormater' => __DIR__ . '/../library/SqlFormater',
        ),
    )
));
require_once 'library/Logic/utils.inc';

// Setup autoloading
require 'init_autoloader.php';
//Setup error handler
//require_once 'e_errorhandler.php';

// Run the application!
Zend\Mvc\Application::init(require 'config/application.config.php')->run();