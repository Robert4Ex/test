
$(function () {
    $('#klient').change(function () {

        var id = $(this).find(":selected").val();

        $('tbody tr').each(function () {

            if (id != 0) {

                if ($(this).attr('class') != id) {

                    $(this).closest('tr').hide();

                } else {

                    $(this).closest('tr').show();
                }
            } else {

                $(this).closest('tr').show();

            }

        });
    });
});
